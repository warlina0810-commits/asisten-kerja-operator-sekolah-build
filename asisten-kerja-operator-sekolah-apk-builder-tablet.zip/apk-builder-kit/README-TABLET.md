# Build APK hanya dengan tablet

Tujuan: membangun APK Asisten Kerja Operator Sekolah tanpa PC menggunakan GitHub Actions.

## Isi kit

- `asisten-kerja-operator-sekolah-v6-final.zip` — source project.
- `.github/workflows/build-apk.yml` — perintah build otomatis di server GitHub.

## Langkah

1. Buat akun/login GitHub di Chrome tablet.
2. Buat repository baru, misalnya `asisten-kerja-operator-sekolah-build`.
3. Jangan centang README saat membuat repository.
4. Di repository, pilih **Add file → Upload files**.
5. Upload dua item dari kit ini:
   - `asisten-kerja-operator-sekolah-v6-final.zip`
   - folder/file `.github/workflows/build-apk.yml` (jika GitHub mobile sulit mengunggah folder, buat file baru dengan path `.github/workflows/build-apk.yml`, lalu tempel isi file tersebut).
6. Commit changes.
7. Buka tab **Actions**.
8. Pilih workflow **Build Android APK**.
9. Jika belum otomatis berjalan, pilih **Run workflow**.
10. Tunggu sampai status hijau.
11. Buka hasil workflow tersebut.
12. Di bagian **Artifacts**, download `asisten-kerja-operator-sekolah-apk`.
13. Ekstrak ZIP artifact.
14. Install `asisten-kerja-operator-sekolah-debug.apk` di tablet.

APK dibuat oleh Android/Gradle di runner GitHub, bukan dengan mengganti ekstensi ZIP. Jika build gagal, buka workflow → job → langkah yang merah dan kirim screenshot/log errornya.
