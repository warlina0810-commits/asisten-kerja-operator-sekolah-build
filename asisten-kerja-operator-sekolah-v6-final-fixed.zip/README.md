# Asisten Kerja Operator Sekolah — V6 Final

Aplikasi offline-first untuk membantu operator sekolah mengelola pekerjaan, agenda, pengingat, dokumen, guru, siswa, sekolah, riwayat, dan asisten AI. UI utama menggunakan Bahasa Indonesia dan dirancang untuk tablet Android.

## Arsitektur

```text
Android / Web
   │
   ├─ React + TypeScript + Vite
   ├─ IndexedDB (offline-first)
   ├─ Sync Queue (outbox)
   └─ Capacitor Local Notifications
             │
          HTTPS API
             │
          FastAPI
        ┌────┴─────┐
        │          │
    PostgreSQL   File Storage
```

Perangkat tetap dapat dipakai tanpa internet. Saat koneksi tersedia, perubahan pada antrean sinkronisasi dikirim ke server. Sinkronisasi server memiliki idempotensi melalui `sync_changes`, dan konflik record menggunakan `updated_at`.

## Fitur final

- Dashboard pekerjaan operator.
- Data sekolah, guru, siswa, pekerjaan, dokumen, pengingat, dan audit log.
- Database lokal IndexedDB.
- Backup/restore JSON lokal.
- Login dan registrasi operator.
- Role `admin`, `kepala_sekolah`, `operator`.
- Pembatasan akses berdasarkan `school_id`.
- Password hashing scrypt.
- Token akses bertanda tangan HS256.
- Rate limiting login sederhana.
- Perubahan password.
- Antrean sinkronisasi offline/online.
- Idempotensi sinkronisasi.
- Upload dokumen aktual dengan batas ukuran.
- Notifikasi lokal Android.
- PostgreSQL cloud/server.
- Docker Compose.
- Reverse proxy HTTPS dengan Caddy.
- Bootstrap admin pertama.
- Audit trail untuk aktivitas login, registrasi, perubahan akun, upload, dan sinkronisasi.

## 1. Build web

Prasyarat: Node.js 20+.

```bash
npm install
npm run build
```

Hasilnya berada di `dist/`.

## 2. Build Android

Prasyarat: Android Studio, Android SDK, Java/JDK yang kompatibel, dan Node.js.

```bash
npm install
npx cap add android
npm run cap:sync
npx cap open android
```

Di Android Studio gunakan **Build → Generate App Bundles or APKs → Generate APKs**.

Atau setelah folder `android/` tersedia:

```bash
npm run android:build
```

APK debug biasanya:

`android/app/build/outputs/apk/debug/app-debug.apk`

> Lingkungan pembuatan paket ini tidak memiliki Android SDK/Gradle lengkap, sehingga file APK final tidak diklaim sudah dibangun atau diuji di sini.

## 3. Menjalankan server produksi

Salin:

```text
backend/.env.example → .env
```

Isi minimal:

```env
POSTGRES_DB=asisten_operator
POSTGRES_USER=operator
POSTGRES_PASSWORD=...
JWT_SECRET=...
CORS_ORIGINS=https://api.sekolah.example.id,capacitor://localhost,http://localhost
ENVIRONMENT=production
```

Generate secret acak yang panjang. Jangan masukkan `.env` ke repository.

Jalankan:

```bash
docker compose up -d --build
```

Status API:

```text
http://127.0.0.1:8000/health
```

Untuk produksi publik gunakan Caddy/HTTPS. Contoh konfigurasi ada di `deploy/Caddyfile.example`.

## 4. Membuat admin pertama

Pastikan minimal satu sekolah sudah ada. Setelah database aktif:

```bash
docker compose exec api python create_admin.py \
  --email admin@sekolah.id \
  --name "Admin Sekolah" \
  --school-id sekolah-001 \
  --password 'GantiPasswordKuat!123'
```

Ganti semua nilai contoh tersebut.

## 5. Konfigurasi tablet

Di aplikasi buka Pengaturan dan isi **URL Backend API** dengan alamat HTTPS server, misalnya:

```text
https://api.sekolah.example.id
```

Jangan memakai `localhost` pada tablet untuk menunjuk server sekolah. `localhost` pada tablet berarti perangkat tablet itu sendiri.

## 6. Database

Skema PostgreSQL ada di:

```text
database/schema.sql
```

Tabel utama:

- schools
- users
- teachers
- students
- work_items
- documents
- reminders
- audit_logs
- sync_changes

Docker volume menyimpan PostgreSQL dan file upload agar restart container tidak menghapus data.

## 7. Keamanan produksi

Sebelum publik:

- Gunakan HTTPS.
- Gunakan secret acak untuk `JWT_SECRET` dan password PostgreSQL.
- Batasi `CORS_ORIGINS` ke origin yang diperlukan.
- Jangan commit `.env`.
- Lakukan backup PostgreSQL dan volume dokumen secara berkala.
- Uji restore backup sebelum dianggap sebagai strategi pemulihan.
- Jangan menaruh API secret pihak ketiga/AI di aplikasi Android.

## Status implementasi

Source project sudah disiapkan sebagai paket final V6. Build APK tetap memerlukan Android SDK/Gradle pada mesin yang menjalankan proses build. Integrasi AI eksternal, Google Drive/Calendar/Gmail, dan object storage cloud dapat ditambahkan tanpa mengganti database lokal/offline-first yang sudah ada.
