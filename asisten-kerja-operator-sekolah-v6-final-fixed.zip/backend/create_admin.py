"""Bootstrap akun admin pertama.
Gunakan sekali setelah database dibuat:
  python create_admin.py --email admin@sekolah.id --name Admin --school-id sekolah-001 --password 'GantiPassword!123'
"""
from __future__ import annotations
import argparse
import secrets
import sys
from pathlib import Path

# Jalankan dari folder backend agar import main bekerja.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from main import get_conn, password_hash

p = argparse.ArgumentParser()
p.add_argument('--email', required=True)
p.add_argument('--name', required=True)
p.add_argument('--school-id', required=True)
p.add_argument('--password', required=True)
a = p.parse_args()

if len(a.password) < 8:
    raise SystemExit('Password minimal 8 karakter')

with get_conn() as conn, conn.cursor() as cur:
    cur.execute('select 1 from schools where school_id=%s and is_active=true', (a.school_id,))
    if not cur.fetchone():
        raise SystemExit('school-id tidak ditemukan')
    cur.execute('select 1 from users where lower(email)=lower(%s)', (a.email,))
    if cur.fetchone():
        raise SystemExit('Email sudah terdaftar')
    uid = secrets.token_hex(16)
    cur.execute(
        "insert into users(id,email,name,password_hash,school_id,is_active,created_at,role) values(%s,%s,%s,%s,%s,true,now(),'admin')",
        (uid, a.email.lower(), a.name.strip(), password_hash(a.password), a.school_id),
    )
    conn.commit()
print(f'Admin dibuat: {a.email} / sekolah={a.school_id}')
