# FastAPI Backend

Backend online untuk Asisten Kerja Operator Sekolah.

## Jalankan lokal

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows
# .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

Atur `DATABASE_URL` dan variable lain melalui `.env` atau environment.

## Endpoint inti

- `POST /api/v1/auth/register`
- `POST /api/v1/auth/login`
- `GET /api/v1/auth/me`
- `POST /api/v1/auth/change-password`
- `POST /api/v1/sync`
- `GET /api/v1/schools`
- `GET /api/v1/schools/{school_id}/snapshot`
- `POST /api/v1/files/upload`
- `GET /api/v1/files/{filename}`
- `GET /api/v1/admin/users`
- `PATCH /api/v1/admin/users/{user_id}/role`
- `PATCH /api/v1/admin/users/{user_id}/active`
- `POST /api/v1/admin/schools`
- `GET /health`

## Bootstrap admin

```bash
python create_admin.py --email admin@sekolah.id --name "Admin" --school-id sekolah-001 --password 'GantiPassword!123'
```

Registrasi publik selalu menghasilkan role `operator`.
