from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import psycopg
from fastapi import Depends, FastAPI, File, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, EmailStr, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    DATABASE_URL: str = "postgresql://operator:operator_password@localhost:5432/asisten_operator"
    CORS_ORIGINS: str = "http://localhost:5173,capacitor://localhost,http://localhost"
    APP_NAME: str = "Asisten Kerja Operator Sekolah API"
    JWT_SECRET: str = "CHANGE_ME_TO_A_LONG_RANDOM_SECRET"
    TOKEN_MINUTES: int = 720
    UPLOAD_DIR: str = "./storage/uploads"
    MAX_UPLOAD_MB: int = 10
    MAX_SYNC_CHANGES: int = 500
    RATE_LIMIT_WINDOW_SECONDS: int = 60
    RATE_LIMIT_LOGIN_ATTEMPTS: int = 8
    PASSWORD_MIN_LENGTH: int = 8
    TRUST_PROXY: bool = False


settings = Settings()
if len(settings.JWT_SECRET) < 32 or settings.JWT_SECRET.startswith("CHANGE_ME"):
    if os.getenv("ENVIRONMENT", "development").lower() in {"production", "prod"}:
        raise RuntimeError("JWT_SECRET wajib diisi dengan secret acak minimal 32 karakter pada production")

app = FastAPI(title=settings.APP_NAME, version="3.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in settings.CORS_ORIGINS.split(",") if x.strip()],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH"],
    allow_headers=["Authorization", "Content-Type", "Accept"],
)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if request.url.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store"
    if request.url.scheme == "https":
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response


TABLES = {"schools", "teachers", "students", "work_items", "documents", "reminders", "audit_logs"}
MUTABLE_TABLES = TABLES - {"audit_logs"}
ROLES = {"admin", "kepala_sekolah", "operator"}
LOGIN_BUCKETS: dict[str, list[float]] = {}
bearer = HTTPBearer(auto_error=False)
Path(settings.UPLOAD_DIR).mkdir(parents=True, exist_ok=True)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime | None = None) -> str:
    return (dt or utcnow()).isoformat()


def get_conn():
    return psycopg.connect(settings.DATABASE_URL)


def b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def password_hash(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1)
    return f"scrypt${b64(salt)}${b64(digest)}"


def password_verify(password: str, encoded: str) -> bool:
    try:
        _, salt_b64, digest_b64 = encoded.split("$")
        salt = base64.urlsafe_b64decode(salt_b64 + "==")
        expected = base64.urlsafe_b64decode(digest_b64 + "==")
        actual = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1)
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def token_for(user: dict[str, Any]) -> str:
    header = b64(b'{"alg":"HS256","typ":"JWT"}')
    payload = {
        "sub": user["id"],
        "email": user["email"],
        "school_id": user["school_id"],
        "role": user.get("role", "operator"),
        "exp": int((utcnow() + timedelta(minutes=settings.TOKEN_MINUTES)).timestamp()),
    }
    body = header + "." + b64(json.dumps(payload, separators=(",", ":")).encode())
    sig = b64(hmac.new(settings.JWT_SECRET.encode(), body.encode(), hashlib.sha256).digest())
    return body + "." + sig


def current_user(creds: HTTPAuthorizationCredentials | None = Depends(bearer)):
    if not creds:
        raise HTTPException(401, "Autentikasi diperlukan")
    try:
        body, sig = creds.credentials.rsplit(".", 1)
        expected = b64(hmac.new(settings.JWT_SECRET.encode(), body.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, expected):
            raise ValueError("signature")
        header_b64, payload_b64 = body.split(".", 1)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64 + "=="))
        if int(payload["exp"]) < int(utcnow().timestamp()):
            raise ValueError("expired")
        with get_conn() as conn, conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
            cur.execute("select id,email,name,school_id,is_active,role from users where id=%s", (payload["sub"],))
            db_user = cur.fetchone()
        if not db_user or not db_user["is_active"]:
            raise ValueError("inactive")
        if db_user["school_id"] != payload.get("school_id"):
            raise ValueError("school")
        payload.update({"email": db_user["email"], "school_id": db_user["school_id"], "role": db_user.get("role", "operator")})
        return payload
    except Exception:
        raise HTTPException(401, "Token tidak valid, akun tidak aktif, atau sudah kedaluwarsa")


def require_roles(*roles: str):
    def dependency(user=Depends(current_user)):
        if user.get("role", "operator") not in roles:
            raise HTTPException(403, "Peran akun tidak memiliki izin untuk operasi ini")
        return user

    return dependency


def client_key(request: Request, email: str = "") -> str:
    host = request.client.host if request.client else "unknown"
    return f"{host}:{email.strip().lower()}"


def rate_limit_login(request: Request, email: str):
    now = utcnow().timestamp()
    key = client_key(request, email)
    recent = [t for t in LOGIN_BUCKETS.get(key, []) if now - t < settings.RATE_LIMIT_WINDOW_SECONDS]
    if len(recent) >= settings.RATE_LIMIT_LOGIN_ATTEMPTS:
        raise HTTPException(429, "Terlalu banyak percobaan login. Coba lagi beberapa saat.")
    recent.append(now)
    LOGIN_BUCKETS[key] = recent


def table_columns(conn, table: str) -> list[str]:
    with conn.cursor() as cur:
        cur.execute(
            "select column_name from information_schema.columns where table_schema=%s and table_name=%s order by ordinal_position",
            ("public", table),
        )
        return [r[0] for r in cur.fetchall()]


def upsert_record(conn, table: str, record: dict[str, Any]) -> None:
    cols = [c for c in table_columns(conn, table) if c in record]
    if "id" not in cols:
        raise HTTPException(400, f"Record {table} wajib memiliki id")
    vals = [record[c] for c in cols]
    updates = ",".join(f"{c}=excluded.{c}" for c in cols if c != "id")
    if not updates:
        return
    where = ""
    if table != "audit_logs" and "updated_at" in cols:
        where = f" where excluded.updated_at >= {table}.updated_at or {table}.updated_at is null"
    with conn.cursor() as cur:
        cur.execute(
            f"insert into {table} ({','.join(cols)}) values ({','.join(['%s']*len(cols))}) "
            f"on conflict (id) do update set {updates}{where}",
            vals,
        )


def list_school_records(conn, table: str, school_id: str):
    with conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
        cur.execute(f"select * from {table} where school_id=%s", (school_id,))
        return cur.fetchall()


def audit(conn, actor: str, school_id: str, action: str, entity_type: str, entity_id: str, notes: str = ""):
    with conn.cursor() as cur:
        cur.execute(
            "insert into audit_logs(id,timestamp,action,actor,entity_type,entity_id,school_id,notes) values(%s,%s,%s,%s,%s,%s,%s,%s)",
            (secrets.token_hex(16), utcnow(), action, actor, entity_type, entity_id, school_id, notes),
        )


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    name: str = Field(min_length=1, max_length=150)
    school_id: str = Field(min_length=1, max_length=100)


class PasswordChangeRequest(BaseModel):
    current_password: str = Field(min_length=1, max_length=128)
    new_password: str = Field(min_length=8, max_length=128)


class RoleUpdateRequest(BaseModel):
    role: str


class SchoolCreateRequest(BaseModel):
    school_id: str = Field(min_length=1, max_length=100)
    name: str = Field(min_length=1, max_length=200)
    npsn: str | None = Field(default=None, max_length=50)
    address: str | None = Field(default=None, max_length=500)


class SyncChange(BaseModel):
    change_id: str = Field(min_length=1, max_length=120)
    store: str
    operation: str = Field(pattern="^(upsert|delete)$")
    record: dict[str, Any]


class SyncRequest(BaseModel):
    school_id: str = Field(min_length=1, max_length=100)
    changes: list[SyncChange] = Field(default_factory=list)
    cursor: str | None = None


@app.get("/health")
def health():
    try:
        with get_conn() as conn, conn.cursor() as cur:
            cur.execute("select 1")
        return {"ok": True, "service": settings.APP_NAME, "server_time": iso()}
    except Exception:
        raise HTTPException(503, "Database belum tersedia")


@app.post("/api/v1/auth/register")
def register(payload: RegisterRequest):
    with get_conn() as conn, conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
        cur.execute("select id from schools where school_id=%s and is_active=true", (payload.school_id.strip(),))
        if not cur.fetchone():
            raise HTTPException(400, "Sekolah tidak ditemukan")
        cur.execute("select id from users where lower(email)=lower(%s)", (str(payload.email).lower(),))
        if cur.fetchone():
            raise HTTPException(409, "Email sudah terdaftar")
        uid = secrets.token_hex(16)
        cur.execute(
            "insert into users(id,email,name,password_hash,school_id,is_active,created_at,role) values(%s,%s,%s,%s,%s,true,now(),'operator')",
            (uid, str(payload.email).lower(), payload.name.strip(), password_hash(payload.password), payload.school_id.strip()),
        )
        audit(conn, uid, payload.school_id.strip(), "register", "user", uid, "Registrasi akun operator")
        conn.commit()
        user = {"id": uid, "email": str(payload.email).lower(), "school_id": payload.school_id.strip(), "role": "operator"}
        return {"token": token_for(user), "user": {"id": uid, "email": user["email"], "name": payload.name.strip(), "school_id": user["school_id"], "role": "operator"}}


@app.post("/api/v1/auth/login")
def login(payload: LoginRequest, request: Request):
    rate_limit_login(request, str(payload.email))
    with get_conn() as conn, conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
        cur.execute("select id,email,name,password_hash,school_id,is_active,role from users where lower(email)=lower(%s)", (str(payload.email),))
        user = cur.fetchone()
        if not user or not user["is_active"] or not password_verify(payload.password, user["password_hash"]):
            raise HTTPException(401, "Email atau kata sandi salah")
        audit(conn, user["id"], user["school_id"], "login", "user", user["id"], "Login berhasil")
        conn.commit()
        auth_user = {"id": user["id"], "email": user["email"], "school_id": user["school_id"], "role": user.get("role", "operator")}
        return {"token": token_for(auth_user), "user": {**auth_user, "name": user["name"]}}


@app.get("/api/v1/auth/me")
def me(user=Depends(current_user)):
    with get_conn() as conn, conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
        cur.execute("select id,email,name,school_id,is_active,role from users where id=%s", (user["sub"],))
        result = cur.fetchone()
        if not result or not result["is_active"]:
            raise HTTPException(401, "Akun tidak aktif")
        return result


@app.post("/api/v1/auth/change-password")
def change_password(payload: PasswordChangeRequest, user=Depends(current_user)):
    with get_conn() as conn, conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
        cur.execute("select password_hash from users where id=%s", (user["sub"],))
        row = cur.fetchone()
        if not row or not password_verify(payload.current_password, row["password_hash"]):
            raise HTTPException(401, "Kata sandi saat ini salah")
        cur.execute("update users set password_hash=%s, updated_at=now() where id=%s", (password_hash(payload.new_password), user["sub"]))
        audit(conn, user["sub"], user["school_id"], "change_password", "user", user["sub"], "Password diubah")
        conn.commit()
    return {"ok": True}


@app.post("/api/v1/sync")
def sync(payload: SyncRequest, user=Depends(current_user)):
    if payload.school_id != user["school_id"]:
        raise HTTPException(403, "Akses sekolah tidak sesuai akun")
    if len(payload.changes) > settings.MAX_SYNC_CHANGES:
        raise HTTPException(413, f"Maksimal {settings.MAX_SYNC_CHANGES} perubahan per sinkronisasi")
    rejected: list[dict[str, str]] = []
    accepted_change_ids: list[str] = []
    applied = 0
    with get_conn() as conn:
        for change in payload.changes:
            if change.store not in MUTABLE_TABLES:
                rejected.append({"change_id": change.change_id, "reason": "store_tidak_diizinkan"})
                continue
            with conn.cursor() as cur:
                cur.execute("select 1 from sync_changes where change_id=%s", (change.change_id,))
                if cur.fetchone():
                    accepted_change_ids.append(change.change_id)
                    continue
            record = dict(change.record)
            if record.get("school_id") != payload.school_id:
                rejected.append({"change_id": change.change_id, "reason": "school_id_tidak_sesuai"})
                continue
            if change.operation == "delete":
                record["is_active"] = False
                record["deleted_at"] = record.get("deleted_at") or iso()
                record["updated_at"] = record.get("updated_at") or record["deleted_at"]
            try:
                upsert_record(conn, change.store, record)
                with conn.cursor() as cur:
                    cur.execute(
                        "insert into sync_changes(change_id,school_id,store,operation,entity_id,received_at,actor) values(%s,%s,%s,%s,%s,now(),%s)",
                        (change.change_id, payload.school_id, change.store, change.operation, str(record.get("id", "")), user["sub"]),
                    )
                audit(conn, user["sub"], payload.school_id, f"sync_{change.operation}", change.store, str(record.get("id", "")), f"change_id={change.change_id}")
                applied += 1
                accepted_change_ids.append(change.change_id)
            except Exception as exc:
                rejected.append({"change_id": change.change_id, "reason": str(exc)[:300]})
        conn.commit()
        snapshot_data = {table: list_school_records(conn, table, payload.school_id) for table in TABLES}
    return {"ok": True, "applied": applied, "accepted_change_ids": accepted_change_ids, "rejected": rejected, "server_time": iso(), "snapshot": snapshot_data}


@app.get("/api/v1/schools/{school_id}/snapshot")
def snapshot(school_id: str, user=Depends(current_user)):
    if school_id != user["school_id"]:
        raise HTTPException(403, "Akses sekolah tidak sesuai akun")
    with get_conn() as conn:
        return {table: list_school_records(conn, table, school_id) for table in TABLES}


@app.get("/api/v1/schools")
def schools(user=Depends(current_user)):
    with get_conn() as conn, conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
        cur.execute("select * from schools where school_id=%s and is_active=true", (user["school_id"],))
        return cur.fetchall()


@app.get("/api/v1/admin/users")
def admin_users(user=Depends(require_roles("admin"))):
    with get_conn() as conn, conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
        cur.execute("select id,email,name,school_id,is_active,created_at,updated_at,role from users order by created_at desc")
        return cur.fetchall()


@app.patch("/api/v1/admin/users/{user_id}/role")
def admin_update_role(user_id: str, payload: RoleUpdateRequest, user=Depends(require_roles("admin"))):
    if payload.role not in ROLES:
        raise HTTPException(400, "Role tidak valid")
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute("update users set role=%s, updated_at=now() where id=%s", (payload.role, user_id))
        if cur.rowcount == 0:
            raise HTTPException(404, "Pengguna tidak ditemukan")
        audit(conn, user["sub"], user["school_id"], "change_role", "user", user_id, payload.role)
        conn.commit()
    return {"ok": True, "user_id": user_id, "role": payload.role}


@app.patch("/api/v1/admin/users/{user_id}/active")
def admin_update_active(user_id: str, active: bool, user=Depends(require_roles("admin"))):
    if user_id == user["sub"] and not active:
        raise HTTPException(400, "Admin tidak dapat menonaktifkan akunnya sendiri")
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute("update users set is_active=%s, updated_at=now() where id=%s", (active, user_id))
        if cur.rowcount == 0:
            raise HTTPException(404, "Pengguna tidak ditemukan")
        audit(conn, user["sub"], user["school_id"], "set_active", "user", user_id, str(active))
        conn.commit()
    return {"ok": True, "user_id": user_id, "is_active": active}


@app.post("/api/v1/admin/schools")
def admin_create_school(payload: SchoolCreateRequest, user=Depends(require_roles("admin"))):
    sid = payload.school_id.strip()
    if not sid or not payload.name.strip():
        raise HTTPException(400, "school_id dan nama sekolah wajib diisi")
    with get_conn() as conn, conn.cursor() as cur:
        try:
            cur.execute(
                "insert into schools(id,school_id,name,npsn,address,is_active,created_at,updated_at) values(%s,%s,%s,%s,%s,true,now(),now())",
                (secrets.token_hex(16), sid, payload.name.strip(), payload.npsn, payload.address),
            )
        except psycopg.errors.UniqueViolation:
            raise HTTPException(409, "school_id sudah digunakan")
        audit(conn, user["sub"], user["school_id"], "create_school", "school", sid, sid)
        conn.commit()
    return {"ok": True, "school_id": sid}


ALLOWED_UPLOADS = {
    "application/pdf": ".pdf",
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/msword": ".doc",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
}


@app.post("/api/v1/files/upload")
async def upload_file(file: UploadFile = File(...), user=Depends(current_user)):
    if file.content_type not in ALLOWED_UPLOADS:
        raise HTTPException(400, "Jenis file tidak didukung")
    fid = secrets.token_hex(16)
    ext = ALLOWED_UPLOADS[file.content_type]
    path = Path(settings.UPLOAD_DIR) / f"{fid}{ext}"
    total = 0
    with path.open("wb") as out:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > settings.MAX_UPLOAD_MB * 1024 * 1024:
                path.unlink(missing_ok=True)
                raise HTTPException(413, f"Ukuran file maksimal {settings.MAX_UPLOAD_MB} MB")
            out.write(chunk)
    safe_name = Path(file.filename or "dokumen").name
    with get_conn() as conn:
        audit(conn, user["sub"], user["school_id"], "upload", "file", fid, safe_name)
        conn.commit()
    return {"id": fid, "filename": safe_name, "content_type": file.content_type, "size": total, "url": f"/api/v1/files/{fid}{ext}"}


@app.get("/api/v1/files/{filename}")
def get_file(filename: str, user=Depends(current_user)):
    safe = Path(filename).name
    path = Path(settings.UPLOAD_DIR) / safe
    if not path.exists() or not path.is_file():
        raise HTTPException(404, "File tidak ditemukan")
    return FileResponse(path)
