export type UserRole = 'admin'|'kepala_sekolah'|'operator';
export interface AuthUser { id:string; email:string; name:string; school_id:string; role:UserRole; }
export interface AuthResponse { token:string; user:AuthUser; }
const TOKEN_KEY='operator_auth_token'; const USER_KEY='operator_auth_user';
export const getAuthToken=()=>localStorage.getItem(TOKEN_KEY)||'';
export const getAuthUser=():AuthUser|null=>{try{return JSON.parse(localStorage.getItem(USER_KEY)||'null')}catch{return null}};
export const setAuth=(data:AuthResponse)=>{localStorage.setItem(TOKEN_KEY,data.token);localStorage.setItem(USER_KEY,JSON.stringify(data.user));};
export const clearAuth=()=>{localStorage.removeItem(TOKEN_KEY);localStorage.removeItem(USER_KEY)};
export async function login(base:string,email:string,password:string){const r=await fetch(`${base.replace(/\/$/,'')}/api/v1/auth/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})});if(!r.ok)throw new Error((await r.json().catch(()=>({}))).detail||'Login gagal');const data=await r.json();setAuth(data);return data as AuthResponse;}
export async function register(base:string,payload:{email:string;password:string;name:string;school_id:string}){const r=await fetch(`${base.replace(/\/$/,'')}/api/v1/auth/register`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});if(!r.ok)throw new Error((await r.json().catch(()=>({}))).detail||'Pendaftaran gagal');const data=await r.json();setAuth(data);return data as AuthResponse;}
