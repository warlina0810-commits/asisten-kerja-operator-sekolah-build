export type SyncStore = 'schools'|'teachers'|'students'|'work_items'|'documents'|'reminders'|'audit_logs';
export type SyncOperation = 'upsert'|'delete';

export interface SyncQueueItem {
  id: string;
  store: SyncStore;
  operation: SyncOperation;
  record: any;
  created_at: string;
  attempts: number;
  last_error?: string | null;
}

export interface SyncResult {
  ok: boolean;
  applied: number;
  accepted_change_ids: string[];
  rejected: Array<{ change_id: string; reason: string }>;
  server_time: string;
  snapshot: Record<string, any[]>;
}

export const SYNC_API_URL_KEY = 'sync_api_url';

export function getSyncApiUrl(): string {
  return (localStorage.getItem(SYNC_API_URL_KEY) || '').replace(/\/$/, '');
}

export function setSyncApiUrl(url: string) {
  const normalized = url.trim().replace(/\/$/, '');
  if (normalized) localStorage.setItem(SYNC_API_URL_KEY, normalized);
  else localStorage.removeItem(SYNC_API_URL_KEY);
}

export function authHeaders(): Record<string,string> { const token = localStorage.getItem('operator_auth_token') || ''; return token ? { Authorization: `Bearer ${token}` } : {}; }

export function isOnline(): boolean {
  return typeof navigator === 'undefined' ? true : navigator.onLine;
}

export async function pingSyncApi(): Promise<boolean> {
  const base = getSyncApiUrl();
  if (!base || !isOnline()) return false;
  try {
    const response = await fetch(`${base}/health`, { method: 'GET', headers: { Accept: 'application/json', ...authHeaders() } });
    return response.ok;
  } catch {
    return false;
  }
}

export async function pushAndPullSync(schoolId: string, changes: SyncQueueItem[]): Promise<SyncResult | null> {
  const base = getSyncApiUrl();
  if (!base || !isOnline()) return null;
  const response = await fetch(`${base}/api/v1/sync`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json', ...authHeaders() },
    body: JSON.stringify({
      school_id: schoolId,
      changes: changes.map(c => ({ change_id: c.id, store: c.store, operation: c.operation, record: c.record }))
    })
  });
  if (!response.ok) throw new Error(`Sync gagal (${response.status})`);
  return await response.json() as SyncResult;
}

export async function uploadDocumentFile(file: File): Promise<{id:string; filename:string; content_type:string; size:number; url:string}> { const base=getSyncApiUrl(); if(!base) throw new Error('URL backend belum diatur'); const body=new FormData(); body.append('file',file); const r=await fetch(`${base}/api/v1/files/upload`,{method:'POST',headers:authHeaders(),body}); if(!r.ok) throw new Error((await r.json().catch(()=>({}))).detail||`Upload gagal (${r.status})`); return await r.json(); }
