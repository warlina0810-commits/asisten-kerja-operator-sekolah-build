import { LocalNotifications } from '@capacitor/local-notifications';
export async function requestNotificationPermission(){const p=await LocalNotifications.requestPermissions();return p.display==='granted';}
export async function scheduleReminder(id:string,title:string,at:string,body='Pengingat pekerjaan operator sekolah'){const ok=await requestNotificationPermission();if(!ok)return false;await LocalNotifications.schedule({notifications:[{id:Math.abs(hash(id)),title,body,schedule:{at:new Date(at)},extra:{reminderId:id}}]});return true;}
export async function cancelReminder(id:string){await LocalNotifications.cancel({notifications:[{id:Math.abs(hash(id))}]});}
function hash(s:string){let h=0;for(let i=0;i<s.length;i++)h=((h<<5)-h)+s.charCodeAt(i)|0;return h||1;}
