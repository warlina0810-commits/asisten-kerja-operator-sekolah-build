import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'id.sekolah.asistenkerjaoperator',
  appName: 'Asisten Kerja Operator Sekolah',
  webDir: 'dist',
};

export default config;
