-- PostgreSQL schema untuk sinkronisasi online Asisten Kerja Operator Sekolah.
-- Database lokal Android tetap menggunakan IndexedDB.

create table if not exists schools (
  id text primary key, school_id text unique not null, name text not null, npsn text, address text,
  created_at timestamptz not null default now(), updated_at timestamptz, deleted_at timestamptz,
  deleted_by text, delete_reason text, is_active boolean not null default true
);

create table if not exists teachers (
  id text primary key, school_id text not null references schools(school_id), name text not null, nip text, nuptk text, role text,
  created_at timestamptz not null default now(), updated_at timestamptz, deleted_at timestamptz, deleted_by text, delete_reason text, is_active boolean not null default true
);

create table if not exists students (
  id text primary key, school_id text not null references schools(school_id), name text not null, nisn text, nik text, grade text, parent_name text,
  created_at timestamptz not null default now(), updated_at timestamptz, deleted_at timestamptz, deleted_by text, delete_reason text, is_active boolean not null default true
);

create table if not exists work_items (
  id text primary key, school_id text not null references schools(school_id), title text not null, description text not null default '',
  work_type text not null, status text not null, priority text not null, urgency text not null, source text, requester_name text,
  due_at timestamptz, event_at timestamptz, postpone_until timestamptz, postpone_reason text, data_expected text, person_expected text, obstacle text, notes text,
  completed_at timestamptz, related_entities integer not null default 0, parent_work_item_id text,
  created_at timestamptz not null default now(), updated_at timestamptz, deleted_at timestamptz, deleted_by text, delete_reason text, is_active boolean not null default true
);

create table if not exists documents (
  id text primary key, school_id text not null references schools(school_id), title text not null, file_type text, size text, url text, summary text,
  created_at timestamptz not null default now(), updated_at timestamptz, deleted_at timestamptz, deleted_by text, delete_reason text, is_active boolean not null default true
);

create table if not exists reminders (
  id text primary key, school_id text not null references schools(school_id), work_item_id text, title text not null, remind_at timestamptz not null, is_done boolean not null default false,
  created_at timestamptz not null default now(), updated_at timestamptz, deleted_at timestamptz, deleted_by text, delete_reason text, is_active boolean not null default true
);

create table if not exists audit_logs (
  id text primary key, timestamp timestamptz not null default now(), action text not null, actor text not null, entity_type text not null, entity_id text not null, school_id text not null, notes text
);

create index if not exists idx_teachers_school on teachers(school_id);
create index if not exists idx_students_school on students(school_id);
create index if not exists idx_work_items_school_status on work_items(school_id, status);
create index if not exists idx_work_items_due on work_items(school_id, due_at);
create index if not exists idx_documents_school on documents(school_id);
create index if not exists idx_reminders_school_time on reminders(school_id, remind_at);
create index if not exists idx_audit_school_time on audit_logs(school_id, timestamp desc);

-- Akun operator untuk akses API online.
create table if not exists users (
  id text primary key,
  email text unique not null,
  name text not null,
  password_hash text not null,
  school_id text not null references schools(school_id),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz,
  role text not null default 'operator' check (role in ('admin','kepala_sekolah','operator'))
);
create index if not exists idx_users_school on users(school_id);

-- Migration aman untuk database yang sudah pernah dibuat sebelum role ditambahkan.
alter table users add column if not exists role text not null default 'operator';
alter table users drop constraint if exists users_role_check;
alter table users add constraint users_role_check check (role in ('admin','kepala_sekolah','operator'));
create index if not exists idx_users_email_lower on users(lower(email));

-- Idempotensi sinkronisasi: mencegah perubahan offline yang sama diterapkan dua kali.
create table if not exists sync_changes (
  change_id text primary key,
  school_id text not null references schools(school_id),
  store text not null,
  operation text not null check (operation in ('upsert','delete')),
  entity_id text not null,
  received_at timestamptz not null default now(),
  actor text not null
);
create index if not exists idx_sync_changes_school_received on sync_changes(school_id, received_at desc);
