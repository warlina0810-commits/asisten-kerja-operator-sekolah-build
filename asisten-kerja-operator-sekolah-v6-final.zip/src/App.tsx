import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { getSyncApiUrl, setSyncApiUrl, pingSyncApi, pushAndPullSync, uploadDocumentFile, type SyncQueueItem, type SyncStore } from './services/sync';
import { login as apiLogin, register as apiRegister, getAuthUser, clearAuth } from './services/auth';
import { scheduleReminder } from './services/notifications';
import { 
  CheckCircle2, Clock, AlertTriangle, Calendar, FileText, 
  Users, School, Activity, Settings, Plus, Search, 
  Menu, X, ChevronRight, Inbox, Play, Pause, XCircle, 
  RotateCcw, History, Link as LinkIcon, Paperclip, Bell,
  Sparkles, MessageSquare, Database, CloudOff, UserCircle,
  Save, Edit3, Trash2, CalendarDays, UploadCloud, RefreshCw, 
  Check, ArrowRight, User, Archive, Eye, MoreVertical
} from 'lucide-react';

// ==========================================
// 1. TYPES & INTERFACES (Domain Models)
// ==========================================
type UUID = string;

export enum WorkType {
  TUGAS = 'Tugas', DEADLINE = 'Deadline', PERMINTAAN = 'Permintaan',
  PELAPORAN = 'Pelaporan', PENDATAAN = 'Pendataan', RAPAT = 'Rapat',
  WEBINAR = 'Webinar', INFORMASI = 'Informasi', TINDAK_LANJUT = 'Tindak Lanjut',
  VERIFIKASI = 'Verifikasi', PELAJARI = 'Pelajari', LAINNYA = 'Lainnya'
}

export enum Status {
  INBOX = 'Kotak Masuk', TODO = 'Belum Dikerjakan', IN_PROGRESS = 'Sedang Dikerjakan',
  WAITING_DATA = 'Menunggu Data', WAITING_OTHER = 'Menunggu Pihak Lain',
  READY_TO_SEND = 'Siap Dikirim', SENT = 'Sudah Dikirim', POSTPONED = 'Ditunda',
  DONE = 'Selesai', CANCELED = 'Dibatalkan'
}

export enum Priority { VERY_HIGH = 'Sangat Tinggi', HIGH = 'Tinggi', NORMAL = 'Normal', LOW = 'Rendah' }
export enum Urgency { VERY_URGENT = 'Sangat Mendesak', URGENT = 'Mendesak', NORMAL = 'Normal', NOT_URGENT = 'Tidak Mendesak', UNKNOWN = 'Belum Diketahui' }

export interface AuditLog {
  id: UUID;
  timestamp: string;
  action: string;
  actor: string;
  entity_type: string;
  entity_id: string;
  school_id: string;
  notes?: string;
}

export interface BaseModel {
  id: UUID;
  school_id: string;
  created_at: string;
  updated_at?: string;
  deleted_at?: string | null;
  deleted_by?: string | null;
  delete_reason?: string | null;
  is_active: boolean;
}

export interface WorkItem extends BaseModel {
  title: string;
  description: string;
  work_type: WorkType;
  status: Status;
  priority: Priority;
  urgency: Urgency;
  source: string;
  requester_name: string;
  due_at?: string | null;
  event_at?: string | null;
  postpone_until?: string | null;
  postpone_reason?: string | null;
  data_expected?: string | null;
  person_expected?: string | null;
  obstacle?: string | null;
  notes?: string | null;
  completed_at?: string | null;
  related_entities: number; 
  parent_work_item_id?: string | null;
}

export interface SchoolData extends BaseModel { name: string; npsn: string; address: string; }
export interface TeacherData extends BaseModel { name: string; nip: string; nuptk: string; role: string; }
export interface StudentData extends BaseModel { name: string; nisn: string; nik: string; grade: string; parent_name: string; }
export interface DocumentData extends BaseModel { title: string; file_type: string; size: string; url?: string; summary?: string; }
export interface ReminderData extends BaseModel { work_item_id?: string; title: string; remind_at: string; is_done: boolean; }

// ==========================================
// 2. MOCK DATA & SERVICE LAYER
// ==========================================
const generateId = () => (typeof crypto !== 'undefined' && 'randomUUID' in crypto) ? crypto.randomUUID() : Math.random().toString(36).substring(2, 9);
const getNow = () => new Date();

class LocalDatabase {
  private dbPromise: Promise<IDBDatabase>;
  private readonly dbName = 'asisten-kerja-operator-sekolah';
  private readonly version = 2;
  private stores = ['schools', 'teachers', 'students', 'work_items', 'documents', 'reminders', 'audit_logs', 'sync_queue'];

  constructor() {
    this.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version);
      request.onupgradeneeded = () => {
        const db = request.result;
        for (const store of this.stores) {
          if (!db.objectStoreNames.contains(store)) {
            const objectStore = db.createObjectStore(store, { keyPath: 'id' });
            if (store !== 'sync_queue') {
              objectStore.createIndex('school_id', 'school_id', { unique: false });
              objectStore.createIndex('is_active', 'is_active', { unique: false });
            }
          }
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async getAll<T>(store: string): Promise<T[]> {
    const db = await this.dbPromise;
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readonly');
      const req = tx.objectStore(store).getAll();
      req.onsuccess = () => resolve(req.result as T[]);
      req.onerror = () => reject(req.error);
    });
  }

  async put<T extends { id: string }>(store: string, value: T): Promise<T> {
    const db = await this.dbPromise;
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).put(value);
      tx.oncomplete = () => resolve(value);
      tx.onerror = () => reject(tx.error);
    });
  }

  async bulkPut<T extends { id: string }>(store: string, values: T[]): Promise<void> {
    const db = await this.dbPromise;
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readwrite');
      const objectStore = tx.objectStore(store);
      values.forEach(v => objectStore.put(v));
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async delete(store: string, id: string): Promise<void> {
    const db = await this.dbPromise;
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async clear(store: string): Promise<void> {
    const db = await this.dbPromise;
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
}

class DatabaseService {
  private db = new LocalDatabase();
  private initialized = false;

  private async ensureSeeded() {
    if (this.initialized) return;
    const schools = await this.db.getAll<SchoolData>('schools');
    if (schools.length === 0) {
      const now = getNow();
      const ystr = new Date(now); ystr.setDate(ystr.getDate() - 1);
      const tmrw = new Date(now); tmrw.setDate(tmrw.getDate() + 1);
      const seedSchools: SchoolData[] = [
        { id: 's1', school_id: 's1', name: 'SDN Merdeka 1', npsn: '20260902', address: 'Jl. Pendidikan 1', is_active: true, created_at: ystr.toISOString() },
        { id: 's2', school_id: 's2', name: 'SDN Merdeka 2', npsn: '20260903', address: 'Jl. Pendidikan 2', is_active: true, created_at: ystr.toISOString() }
      ];
      const teachers: TeacherData[] = [{ id: 't1', school_id: 's1', name: 'Budi Santoso, S.Pd', nip: '19800101', nuptk: '12345', role: 'Kepala Sekolah', is_active: true, created_at: ystr.toISOString() }];
      const students: StudentData[] = [{ id: 'st1', school_id: 's1', name: 'Andi Saputra', nisn: '0123', nik: '3171', grade: 'Kelas 3', parent_name: 'Ibu Siti', is_active: true, created_at: ystr.toISOString() }];
      const items: WorkItem[] = [
        { id: 'w1', school_id: 's1', title: 'Kirim LPJ BOSP Tahap 1', description: 'Segera selesaikan dan kirim LPJ.', work_type: WorkType.PELAPORAN, status: Status.IN_PROGRESS, priority: Priority.VERY_HIGH, urgency: Urgency.VERY_URGENT, source: 'Dinas', requester_name: 'Pak Budi', due_at: tmrw.toISOString(), created_at: ystr.toISOString(), related_entities: 0, is_active: true },
        { id: 'w2', school_id: 's1', title: 'Verifikasi NISN Siswa Pindahan', description: 'Cek ulang NISN Andi.', work_type: WorkType.VERIFIKASI, status: Status.WAITING_DATA, priority: Priority.NORMAL, urgency: Urgency.NORMAL, source: 'Orang Tua', requester_name: 'Ibu Siti', data_expected: 'Scan KK', person_expected: 'Ibu Siti', created_at: now.toISOString(), related_entities: 1, is_active: true }
      ];
      const logs: AuditLog[] = items.map(i => ({ id: generateId(), timestamp: now.toISOString(), action: 'Pekerjaan Dibuat', actor: 'Sistem', entity_type: 'WorkItem', entity_id: i.id, school_id: i.school_id, notes: 'Data awal' }));
      await Promise.all([
        this.db.bulkPut('schools', seedSchools), this.db.bulkPut('teachers', teachers), this.db.bulkPut('students', students),
        this.db.bulkPut('work_items', items), this.db.bulkPut('audit_logs', logs)
      ]);
    }
    this.initialized = true;
  }

  private async logsFor(entityType: string, entityId: string, schoolId: string, action: string, notes?: string) {
    const log = { id: generateId(), timestamp: getNow().toISOString(), action, actor: 'Iqsan', entity_type: entityType, entity_id: entityId, school_id: schoolId, notes };
    await this.db.put('audit_logs', log);
    await this.queueChange('audit_logs', 'upsert', log);
  }

  async getWorkItems(schoolId: string, includeArchived = false) { await this.ensureSeeded(); const rows = await this.db.getAll<WorkItem>('work_items'); return rows.filter(i => i.school_id === schoolId && (includeArchived || i.is_active)); }
  async getSchools() { await this.ensureSeeded(); return (await this.db.getAll<SchoolData>('schools')).filter(s => s.is_active); }
  async getTeachers(schoolId: string) { await this.ensureSeeded(); return (await this.db.getAll<TeacherData>('teachers')).filter(t => t.school_id === schoolId && t.is_active); }
  async getStudents(schoolId: string) { await this.ensureSeeded(); return (await this.db.getAll<StudentData>('students')).filter(s => s.school_id === schoolId && s.is_active); }
  async getAuditLogs(schoolId: string) { await this.ensureSeeded(); return (await this.db.getAll<AuditLog>('audit_logs')).filter(l => l.school_id === schoolId).sort((a,b) => b.timestamp.localeCompare(a.timestamp)); }
  async getReminders(schoolId: string) { await this.ensureSeeded(); return (await this.db.getAll<ReminderData>('reminders')).filter(r => r.school_id === schoolId && r.is_active); }
  async getDocuments(schoolId: string) { await this.ensureSeeded(); return (await this.db.getAll<DocumentData>('documents')).filter(d => d.school_id === schoolId && d.is_active); }

  private async queueChange(store: SyncStore, operation: 'upsert'|'delete', record: any) {
    const change: SyncQueueItem = { id: generateId(), store, operation, record: structuredClone(record), created_at: getNow().toISOString(), attempts: 0, last_error: null };
    await this.db.put('sync_queue', change as any);
  }

  async getPendingSyncChanges(): Promise<SyncQueueItem[]> {
    await this.ensureSeeded();
    return await this.db.getAll<SyncQueueItem>('sync_queue');
  }

  async clearPendingSyncChanges(ids: string[]) {
    for (const id of ids) await this.db.delete('sync_queue', id);
  }

  async markSyncError(ids: string[], error: string) {
    const rows = await this.getPendingSyncChanges();
    for (const row of rows.filter(r => ids.includes(r.id))) { row.attempts += 1; row.last_error = error; await this.db.put('sync_queue', row); }
  }

  async applyServerSnapshot(snapshot: Record<string, any[]>) {
    await this.ensureSeeded();
    const stores = this.dbStores();
    for (const store of stores) {
      const rows = Array.isArray(snapshot[store]) ? snapshot[store] : [];
      if (rows.length) await this.db.bulkPut(store, rows);
    }
  }

  async createWorkItem(data: Partial<WorkItem>) {
    await this.ensureSeeded();
    const newItem = { ...data, id: generateId(), created_at: getNow().toISOString(), is_active: true } as WorkItem;
    await this.db.put('work_items', newItem);
    await this.queueChange('work_items', 'upsert', newItem);
    await this.logsFor('WorkItem', newItem.id, newItem.school_id, 'Pekerjaan Dibuat');
    return newItem;
  }

  async updateWorkItem(id: string, data: Partial<WorkItem>) {
    await this.ensureSeeded();
    const items = await this.db.getAll<WorkItem>('work_items'); const item = items.find(i => i.id === id);
    if (item) { const updated = { ...item, ...data, updated_at: getNow().toISOString() }; await this.db.put('work_items', updated); await this.queueChange('work_items', 'upsert', updated); await this.logsFor('WorkItem', id, updated.school_id, 'Data Diperbarui'); }
  }

  async updateStatus(id: string, newStatus: Status, notes?: string) {
    await this.ensureSeeded();
    const items = await this.db.getAll<WorkItem>('work_items'); const item = items.find(i => i.id === id);
    if (item) {
      const updated = { ...item, status: newStatus, updated_at: getNow().toISOString() };
      let actionText = `Status diubah menjadi: ${newStatus}`;
      if (newStatus === Status.DONE) { updated.completed_at = getNow().toISOString(); actionText = 'Pekerjaan Diselesaikan'; }
      if (newStatus === Status.TODO || newStatus === Status.IN_PROGRESS) updated.completed_at = null;
      await this.db.put('work_items', updated); await this.queueChange('work_items', 'upsert', updated); await this.logsFor('WorkItem', id, updated.school_id, actionText, notes);
    }
  }

  async postpone(id: string, date: string, reason: string) {
    await this.ensureSeeded(); const items = await this.db.getAll<WorkItem>('work_items'); const item = items.find(i => i.id === id);
    if (item) { const updated = { ...item, status: Status.POSTPONED, postpone_until: date, postpone_reason: reason, updated_at: getNow().toISOString() }; await this.db.put('work_items', updated); await this.queueChange('work_items', 'upsert', updated); await this.logsFor('WorkItem', id, updated.school_id, `Ditunda hingga ${new Date(date).toLocaleDateString('id-ID')}`, reason); }
  }

  async waitData(id: string, dataExpected: string, personExpected: string) {
    await this.ensureSeeded(); const items = await this.db.getAll<WorkItem>('work_items'); const item = items.find(i => i.id === id);
    if (item) { const updated = { ...item, status: Status.WAITING_DATA, data_expected: dataExpected, person_expected: personExpected, updated_at: getNow().toISOString() }; await this.db.put('work_items', updated); await this.queueChange('work_items', 'upsert', updated); await this.logsFor('WorkItem', id, updated.school_id, `Menunggu Data: ${dataExpected}`, `Dari: ${personExpected}`); }
  }

  async softDelete(entityType: 'WorkItem'|'Teacher'|'Student'|'School'|'Document'|'Reminder', id: string, reason: string) {
    await this.ensureSeeded();
    const map: Record<string,string> = { WorkItem:'work_items', Teacher:'teachers', Student:'students', School:'schools', Document:'documents', Reminder:'reminders' };
    const store = map[entityType]; const rows = await this.db.getAll<any>(store); const item = rows.find(i => i.id === id);
    if (item) { const updated = { ...item, is_active:false, deleted_at:getNow().toISOString(), deleted_by:'Iqsan', delete_reason:reason }; await this.db.put(store, updated); await this.queueChange(store as SyncStore, 'upsert', updated); await this.logsFor(entityType, id, item.school_id || item.id, 'Data Dinonaktifkan/Diarsipkan', reason); }
  }

  async createMasterData(entityType: 'Teacher'|'Student'|'Document'|'Reminder', data: any) {
    await this.ensureSeeded(); const map: Record<string,string> = { Teacher:'teachers', Student:'students', Document:'documents', Reminder:'reminders' }; const store = map[entityType];
    const newItem = { ...data, id: generateId(), created_at:getNow().toISOString(), is_active:true }; await this.db.put(store, newItem); await this.queueChange(store as SyncStore, 'upsert', newItem); await this.logsFor(entityType, newItem.id, newItem.school_id, `Data ${entityType} Ditambahkan`);
  }

  async updateMasterData(entityType: 'Teacher'|'Student'|'Document'|'Reminder', id: string, data: any) {
    await this.ensureSeeded(); const map: Record<string,string> = { Teacher:'teachers', Student:'students', Document:'documents', Reminder:'reminders' }; const store = map[entityType];
    const rows = await this.db.getAll<any>(store); const item = rows.find(i => i.id === id);
    if (item) { const updated = { ...item, ...data, id: item.id, school_id: item.school_id, updated_at: getNow().toISOString() }; await this.db.put(store, updated); await this.queueChange(store as SyncStore, 'upsert', updated); await this.logsFor(entityType, id, updated.school_id, `Data ${entityType} Diperbarui`); }
  }

  async exportBackup() {
    await this.ensureSeeded();
    const data: Record<string, unknown> = {
      schema_version: 2, exported_at: getNow().toISOString(), app: 'Asisten Kerja Operator Sekolah',
    };
    for (const store of this.dbStores()) data[store] = await this.db.getAll<any>(store);
    return data;
  }

  async importBackup(data: any) {
    const stores = this.dbStores();
    if (!data || data.schema_version !== 2 || !stores.every(k => Array.isArray(data[k]))) {
      throw new Error('File backup tidak valid atau bukan backup aplikasi ini.');
    }
    for (const store of stores) { await this.db.clear(store); await this.db.bulkPut(store, data[store]); }
    await this.db.clear('sync_queue');
    this.initialized = true;
  }

  private dbStores() { return ['schools','teachers','students','work_items','documents','reminders','audit_logs']; }
}

const api = new DatabaseService();

// ==========================================
// 3. UI COMPONENTS & HELPERS
// ==========================================
const Card = ({ children, className = '', onClick }: any) => (
  <div onClick={onClick} className={`bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden ${className} ${onClick ? 'cursor-pointer hover:border-blue-300 transition-colors' : ''}`}>
    {children}
  </div>
);

const Badge = ({ children, variant = 'default', className = '' }: any) => {
  const variants: any = {
    default: 'bg-slate-100 text-slate-800 border border-slate-200',
    primary: 'bg-blue-50 text-blue-800 border border-blue-200',
    danger: 'bg-red-50 text-red-800 border border-red-200',
    warning: 'bg-amber-50 text-amber-800 border border-amber-200',
    success: 'bg-emerald-50 text-emerald-800 border border-emerald-200',
    outline: 'border border-slate-300 text-slate-600 bg-transparent'
  };
  return <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium whitespace-nowrap ${variants[variant]} ${className}`}>{children}</span>;
};

const Button = ({ children, variant = 'primary', className = '', onClick, size="md", disabled=false, type="button", title }: any) => {
  const base = "inline-flex items-center justify-center font-medium rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed";
  const variants: any = {
    primary: "bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500",
    secondary: "bg-slate-100 text-slate-700 hover:bg-slate-200 focus:ring-slate-500",
    danger: "bg-red-600 text-white hover:bg-red-700 focus:ring-red-500",
    ghost: "bg-transparent text-slate-600 hover:bg-slate-100 focus:ring-slate-500",
    outline: "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 focus:ring-slate-500"
  };
  const sizes: any = { sm: "px-3 py-1.5 text-sm", md: "px-4 py-2 text-sm", icon: "p-2" };
  return <button type={type} disabled={disabled} onClick={onClick} title={title} className={`${base} ${variants[variant]} ${sizes[size]} ${className}`}>{children}</button>;
};

// Global Time Helpers
const formatGlobalTime = (date: Date) => {
  return new Intl.DateTimeFormat('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'Asia/Jakarta', timeZoneName: 'short' }).format(date);
};
const formatDateID = (isoString?: string | null, includeTime: boolean = false) => {
  if (!isoString) return '-';
  const options: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta' };
  if (includeTime) { options.hour = '2-digit'; options.minute = '2-digit'; }
  return new Date(isoString).toLocaleDateString('id-ID', options);
};
const isOverdue = (dateString?: string | null) => {
  if (!dateString) return false;
  return new Date(dateString).getTime() < getNow().getTime();
};

const getStatusColor = (status: Status) => {
  switch (status) {
    case Status.TODO: case Status.IN_PROGRESS: return 'primary';
    case Status.WAITING_DATA: case Status.WAITING_OTHER: return 'warning';
    case Status.READY_TO_SEND: case Status.SENT: case Status.DONE: return 'success';
    case Status.POSTPONED: return 'outline';
    case Status.CANCELED: return 'danger';
    default: return 'default';
  }
};

// ==========================================
// 4. MAIN APPLICATION
// ==========================================
export default function App() {
  // --- STATE ---
  const [currentView, setCurrentView] = useState('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const [profile, setProfile] = useState(() => { try { return JSON.parse(localStorage.getItem('operator_profile') || '') || { name: 'Iqsan', email: 'iqsan@operator.id', activeSchoolId: 's1' }; } catch { return { name: 'Iqsan', email: 'iqsan@operator.id', activeSchoolId: 's1' }; } });
  const [workItems, setWorkItems] = useState<WorkItem[]>([]);
  const [schools, setSchools] = useState<SchoolData[]>([]);
  const [teachers, setTeachers] = useState<TeacherData[]>([]);
  const [students, setStudents] = useState<StudentData[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [reminders, setReminders] = useState<ReminderData[]>([]);
  const [documents, setDocuments] = useState<DocumentData[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [showArchived, setShowArchived] = useState(false);
  const [toastMessage, setToastMessage] = useState<{msg: string, type: 'success'|'error'|'info'} | null>(null);
  const [syncApiUrl, setSyncApiUrlState] = useState(() => getSyncApiUrl());
  const [isOnline, setIsOnline] = useState(() => typeof navigator === 'undefined' ? true : navigator.onLine);
  const [syncBusy, setSyncBusy] = useState(false);
  const [syncStatus, setSyncStatus] = useState('Belum disinkronkan');
  const [pendingSyncCount, setPendingSyncCount] = useState(0);
  const [authUser, setAuthUser] = useState(() => getAuthUser());
  const [authMode, setAuthMode] = useState<'login'|'register'>('login');
  const [authEmail, setAuthEmail] = useState(() => profile.email);
  const [authPassword, setAuthPassword] = useState('');
  const [authName, setAuthName] = useState(() => profile.name);
  const [authBusy, setAuthBusy] = useState(false);

  // --- MODALS ---
  const [selectedTask, setSelectedTask] = useState<WorkItem | null>(null);
  const [postponeModal, setPostponeModal] = useState<{isOpen: boolean, task: WorkItem | null}>({isOpen: false, task: null});
  const [waitDataModal, setWaitDataModal] = useState<{isOpen: boolean, task: WorkItem | null}>({isOpen: false, task: null});
  const [editTaskModal, setEditTaskModal] = useState<{isOpen: boolean, task: WorkItem | Partial<WorkItem> | null}>({isOpen: false, task: null});
  const [aiConfirmModal, setAiConfirmModal] = useState<{isOpen: boolean, data: Partial<WorkItem> | null}>({isOpen: false, data: null});
  const [deleteConfirmModal, setDeleteConfirmModal] = useState<{isOpen: boolean, entityType: any, id: string, title: string}>({isOpen: false, entityType: null, id: '', title: ''});
  const [genericFormModal, setGenericFormModal] = useState<{isOpen: boolean, type: 'Teacher'|'Student'|'Reminder'|'Document', data?: any}>({isOpen: false, type: 'Teacher'});

  const handleAuth = async () => {
    if (!syncApiUrl) { showToast('Atur URL Backend API terlebih dahulu', 'error'); return; }
    setAuthBusy(true);
    try {
      const result = authMode === 'login'
        ? await apiLogin(syncApiUrl, authEmail, authPassword)
        : await apiRegister(syncApiUrl, { email: authEmail, password: authPassword, name: authName, school_id: profile.activeSchoolId });
      setAuthUser(result.user);
      setProfile(p => ({ ...p, name: result.user.name, email: result.user.email, activeSchoolId: result.user.school_id }));
      setAuthPassword('');
      showToast(authMode === 'login' ? 'Login berhasil' : 'Akun berhasil dibuat');
      setTimeout(() => syncNow(), 0);
    } catch (e:any) { showToast(e?.message || 'Autentikasi gagal', 'error'); }
    finally { setAuthBusy(false); }
  };

  const handleLogout = () => { clearAuth(); setAuthUser(null); setSyncStatus('Belum login ke server'); showToast('Logout berhasil', 'info'); };

  const refreshSyncState = useCallback(async () => {
    try { setPendingSyncCount((await api.getPendingSyncChanges()).length); } catch { setPendingSyncCount(0); }
  }, []);

  const syncNow = useCallback(async () => {
    if (syncBusy) return;
    const base = getSyncApiUrl();
    if (!base) { setSyncStatus('URL server belum diatur'); return; }
    setSyncBusy(true);
    try {
      const changes = await api.getPendingSyncChanges();
      const result = await pushAndPullSync(profile.activeSchoolId, changes);
      if (!result) { setSyncStatus('Offline / server tidak tersedia'); return; }
      await api.applyServerSnapshot(result.snapshot);
      if (result.accepted_change_ids?.length) await api.clearPendingSyncChanges(result.accepted_change_ids);
      if (result.rejected.length) {
        const rejectedIds = result.rejected.map(r => r.change_id);
        const reason = result.rejected.map(r => r.reason).join('; ');
        await api.markSyncError(rejectedIds, reason || 'Perubahan ditolak server');
      }
      setSyncStatus(`Tersinkron ${result.accepted_change_ids?.length || 0} perubahan pada ${new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}`);
      await refreshSyncState();
      if (result.rejected.length) showToast(`${result.rejected.length} perubahan tetap berada di antrean karena ditolak server`, 'info');
      else if (changes.length) showToast(`${result.accepted_change_ids?.length || changes.length} perubahan berhasil disinkronkan`);
    } catch (e:any) {
      await refreshSyncState();
      setSyncStatus(e?.message || 'Sinkronisasi gagal');
      showToast(e?.message || 'Sinkronisasi gagal', 'error');
    } finally { setSyncBusy(false); }
  }, [profile.activeSchoolId, syncBusy, refreshSyncState]);

  useEffect(() => {
    const online = () => { setIsOnline(true); setTimeout(() => { syncNow(); }, 300); };
    const offline = () => { setIsOnline(false); setSyncStatus('Offline — data tetap tersimpan di perangkat'); };
    window.addEventListener('online', online); window.addEventListener('offline', offline);
    refreshSyncState();
    return () => { window.removeEventListener('online', online); window.removeEventListener('offline', offline); };
  }, [refreshSyncState, syncNow]);

  // --- INITIAL LOAD & REFRESH ---
  const loadData = useCallback(async () => {
    setLoading(true);
    const [w, s, t, st, logs, rem, docs] = await Promise.all([
      api.getWorkItems(profile.activeSchoolId, showArchived), api.getSchools(),
      api.getTeachers(profile.activeSchoolId), api.getStudents(profile.activeSchoolId),
      api.getAuditLogs(profile.activeSchoolId), api.getReminders(profile.activeSchoolId), api.getDocuments(profile.activeSchoolId)
    ]);
    
    // Auto-unpostpone items if time has passed
    const nowTime = getNow().getTime();
    for (let item of w) {
      if (item.status === Status.POSTPONED && item.postpone_until && new Date(item.postpone_until).getTime() <= nowTime) {
         await api.updateStatus(item.id, Status.TODO, 'Batas penundaan lewat, sistem mencairkan pekerjaan otomatis.');
      }
    }
    
    // Fetch again if auto-updated
    const finalW = await api.getWorkItems(profile.activeSchoolId, showArchived);
    setWorkItems(finalW); setSchools(s); setTeachers(t); setStudents(st); setAuditLogs(logs); setReminders(rem); setDocuments(docs);
    setLoading(false);
  }, [profile.activeSchoolId, showArchived]);

  useEffect(() => { loadData(); }, [loadData]);
  useEffect(() => { localStorage.setItem('operator_profile', JSON.stringify(profile)); }, [profile]);

  const showToast = (msg: string, type: 'success'|'error'|'info' = 'success') => {
    setToastMessage({msg, type});
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleBackupExport = async () => {
    try {
      const backup = await api.exportBackup();
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = `backup-asisten-operator-${new Date().toISOString().slice(0,10)}.json`; a.click();
      URL.revokeObjectURL(url);
      showToast('Backup database berhasil dibuat');
    } catch { showToast('Gagal membuat backup', 'error'); }
  };

  const handleBackupImport = async (file?: File) => {
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      if (!confirm('Impor backup akan mengganti seluruh data lokal saat ini. Lanjutkan?')) return;
      await api.importBackup(data);
      showToast('Database berhasil dipulihkan');
      await loadData();
    } catch (e:any) { showToast(e?.message || 'Backup tidak dapat dipulihkan', 'error'); }
  };

  const refreshData = async () => {
    await loadData();
    if (selectedTask) {
      const updated = (await api.getWorkItems(profile.activeSchoolId, true)).find(d => d.id === selectedTask.id);
      setSelectedTask(updated || null);
    }
  };

  const handleStatusChange = async (id: string, newStatus: Status, notes?: string) => {
    await api.updateStatus(id, newStatus, notes);
    showToast(`Status diperbarui menjadi ${newStatus}`);
    await refreshData();
  };

  const changeView = (view: string) => {
     setCurrentView(view);
     setIsMobileMenuOpen(false);
     setSelectedTask(null);
     window.scrollTo(0, 0); // Only scroll top on main view change
  };

  // --- COMPUTED DATA FOR DASHBOARD ---
  const computedStats = useMemo(() => {
    const activeTasks = workItems.filter(t => t.is_active && t.status !== Status.DONE && t.status !== Status.CANCELED);
    
    const needsAttention = [...activeTasks].sort((a, b) => {
      let scoreA = 0; let scoreB = 0;
      if (a.urgency === Urgency.VERY_URGENT) scoreA += 100; if (b.urgency === Urgency.VERY_URGENT) scoreB += 100;
      if (a.urgency === Urgency.URGENT) scoreA += 50; if (b.urgency === Urgency.URGENT) scoreB += 50;
      if (a.priority === Priority.VERY_HIGH) scoreA += 40; if (b.priority === Priority.VERY_HIGH) scoreB += 40;
      if (isOverdue(a.due_at)) scoreA += 200; if (isOverdue(b.due_at)) scoreB += 200;
      
      const isTodayA = a.event_at && new Date(a.event_at).toDateString() === getNow().toDateString();
      const isTodayB = b.event_at && new Date(b.event_at).toDateString() === getNow().toDateString();
      if (isTodayA) scoreA += 150; if (isTodayB) scoreB += 150;

      if (a.status === Status.WAITING_DATA) scoreA -= 20; if (b.status === Status.WAITING_DATA) scoreB -= 20;
      if (a.status === Status.POSTPONED) scoreA -= 500; if (b.status === Status.POSTPONED) scoreB -= 500;
      return scoreB - scoreA;
    });

    const todayDone = workItems.filter(t => t.status === Status.DONE && t.completed_at && new Date(t.completed_at).toDateString() === getNow().toDateString()).length;
    const agendaToday = activeTasks.filter(t => (t.event_at && new Date(t.event_at).toDateString() === getNow().toDateString()) || (t.due_at && new Date(t.due_at).toDateString() === getNow().toDateString()));

    return { 
      needsAttention: needsAttention.slice(0, 6), 
      urgentCount: activeTasks.filter(t => t.urgency === Urgency.VERY_URGENT || t.urgency === Urgency.URGENT).length, 
      overdueCount: activeTasks.filter(t => isOverdue(t.due_at) && t.status !== Status.POSTPONED).length, 
      waitingCount: activeTasks.filter(t => t.status === Status.WAITING_DATA || t.status === Status.WAITING_OTHER).length, 
      totalActive: activeTasks.length,
      todayDone, agendaToday
    };
  }, [workItems]);


  // --- AI SIMULATION LOGIC ---
  const simulateAI = (text: string) => {
    const lower = text.toLowerCase();
    const mockData: Partial<WorkItem> = {
      title: 'Pekerjaan Baru (Saran AI)', description: text,
      priority: Priority.NORMAL, urgency: Urgency.NORMAL,
      status: Status.INBOX, source: 'Chat/Input AI', school_id: profile.activeSchoolId
    };

    if (lower.includes('print') || lower.includes('cetak')) { mockData.work_type = WorkType.PERMINTAAN; mockData.title = 'Cetak Dokumen'; }
    if (lower.includes('rapat')) { mockData.work_type = WorkType.RAPAT; mockData.title = 'Jadwal Rapat'; }
    if (lower.includes('cepat') || lower.includes('segera')) { mockData.urgency = Urgency.VERY_URGENT; mockData.priority = Priority.HIGH; }
    if (lower.includes('besok')) { const tmrw = getNow(); tmrw.setDate(tmrw.getDate() + 1); mockData.due_at = tmrw.toISOString(); }
    if (lower.includes('dinas')) { mockData.source = 'Dinas Pendidikan'; }
    if (lower.includes('mbg') || lower.includes('tinggi badan') || lower.includes('orang tua')) {
       mockData.related_entities = 1; mockData.notes = "Saran AI: Kemungkinan merupakan bagian atau kelanjutan dari pendataan MBG sebelumnya. Disarankan untuk digabungkan/dijadikan sub-pekerjaan.";
    }

    setAiConfirmModal({ isOpen: true, data: mockData });
  };

  // ==========================================
  // 5. SUB-COMPONENTS
  // ==========================================
  
  // Isolated Clock to prevent full app re-renders on input focus
  const TopbarClock = () => {
    const [time, setTime] = useState(getNow());
    useEffect(() => { const timer = setInterval(() => setTime(getNow()), 1000); return () => clearInterval(timer); }, []);
    
    const h = parseInt(new Intl.DateTimeFormat('en-US', { hour: 'numeric', hour12: false, timeZone: 'Asia/Jakarta' }).format(time));
    let greeting = "Selamat malam";
    if (h >= 3 && h < 11) greeting = "Selamat pagi";
    else if (h >= 11 && h < 15) greeting = "Selamat siang";
    else if (h >= 15 && h < 18) greeting = "Selamat sore";

    return (
      <div className="flex flex-col items-center">
        <span className="text-sm font-semibold text-slate-800">{greeting}, {profile.name}.</span>
        <span className="text-xs text-slate-500 flex items-center mt-0.5 tabular-nums"><Calendar className="w-3 h-3 mr-1" />{formatGlobalTime(time)}</span>
      </div>
    );
  };

  const SidebarNav = () => {
    const navItems = [
      { id: 'dashboard', label: 'Beranda', icon: Activity },
      { id: 'tasks', label: 'Pekerjaan', icon: Inbox },
      { id: 'agenda', label: 'Agenda', icon: CalendarDays },
      { id: 'reminders', label: 'Pengingat', icon: Bell },
      { id: 'docs', label: 'Dokumen', icon: FileText },
      { id: 'teachers', label: 'Data Guru', icon: Users },
      { id: 'students', label: 'Data Siswa', icon: Users },
      { id: 'schools', label: 'Data Sekolah', icon: School },
      { id: 'history', label: 'Riwayat Aktivitas', icon: History },
      { id: 'ai', label: 'AI Assistant', icon: Sparkles },
      { id: 'settings', label: 'Pengaturan', icon: Settings },
    ];
    return (
      <nav className="space-y-1">
        {navItems.map((item) => (
          <button key={item.id} onClick={() => changeView(item.id)}
            className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all ${
              currentView === item.id ? 'bg-blue-50 text-blue-700 shadow-sm' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}>
            <item.icon className={`mr-3 h-5 w-5 ${currentView === item.id ? 'text-blue-600' : 'text-slate-400'}`} />
            {item.label}
          </button>
        ))}
      </nav>
    );
  };

  const Topbar = () => (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200">
      <div className="flex items-center justify-between px-4 sm:px-6 lg:px-8 h-16">
        <div className="flex items-center flex-1">
          <button onClick={() => setIsMobileMenuOpen(true)} className="p-2 -ml-2 mr-2 md:hidden text-slate-500 hover:bg-slate-100 rounded-lg"><Menu className="h-6 w-6" /></button>
          <div className="hidden md:flex flex-col"><h1 className="text-lg font-bold text-slate-900 tracking-tight">Asisten Kerja</h1><span className="text-xs font-medium text-blue-600">Operator Sekolah</span></div>
        </div>
        <div className="flex items-center justify-center flex-1 text-center min-w-[300px]"><TopbarClock /></div>
        <div className="flex items-center justify-end flex-1 space-x-2">
           <Badge variant="outline" className="hidden sm:flex items-center space-x-1 border-emerald-200 bg-emerald-50 text-emerald-700" title="Database lokal tersimpan di perangkat"><div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div><span>{isOnline ? 'Online + Lokal' : 'Offline + Lokal'}</span></Badge>
           <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full relative"><Bell className="w-5 h-5" />{computedStats.urgentCount > 0 && (<span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-500 border-2 border-white"></span>)}</button>
           <button onClick={() => changeView('settings')} className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold text-sm shadow-sm ring-2 ring-white hover:ring-blue-200 transition-all">{profile.name.charAt(0)}</button>
        </div>
      </div>
    </header>
  );

  const AIAssistantInput = () => {
    // Extracted into its own component so typing doesn't get interrupted by global renders
    const [text, setText] = useState('');
    const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); if(text.trim()) { simulateAI(text); setText(''); } };
    return (
      <Card className="p-1">
        <form onSubmit={handleSubmit} className="relative flex items-center">
           <div className="absolute left-4 text-slate-400"><MessageSquare className="w-5 h-5" /></div>
           <input type="text" value={text} onChange={(e) => setText(e.target.value)} placeholder='Ketik pesan masuk, tugas, atau paste dari WhatsApp...' className="w-full pl-12 pr-32 py-4 rounded-xl border-none focus:ring-0 text-slate-700 placeholder-slate-400 bg-transparent outline-none" />
           <div className="absolute right-2"><Button type="submit" size="sm" className="rounded-lg shadow-sm"><Sparkles className="w-4 h-4 mr-2"/> Proses AI</Button></div>
        </form>
      </Card>
    );
  };

  const DashboardView = () => (
    <div className="space-y-6 animate-in fade-in duration-300">
      <AIAssistantInput />
      
      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4 bg-gradient-to-br from-red-50 to-white border-red-100">
           <div className="flex justify-between items-start"><div><p className="text-sm font-medium text-red-600">Terlambat & Urgent</p><h3 className="text-2xl font-bold text-slate-900 mt-1">{computedStats.overdueCount + computedStats.urgentCount}</h3></div><div className="p-2 bg-red-100 rounded-lg"><AlertTriangle className="w-5 h-5 text-red-600" /></div></div>
        </Card>
        <Card className="p-4 bg-gradient-to-br from-blue-50 to-white border-blue-100">
           <div className="flex justify-between items-start"><div><p className="text-sm font-medium text-blue-600">Total Aktif</p><h3 className="text-2xl font-bold text-slate-900 mt-1">{computedStats.totalActive}</h3></div><div className="p-2 bg-blue-100 rounded-lg"><Activity className="w-5 h-5 text-blue-600" /></div></div>
        </Card>
        <Card className="p-4 bg-gradient-to-br from-amber-50 to-white border-amber-100">
           <div className="flex justify-between items-start"><div><p className="text-sm font-medium text-amber-700">Menunggu Data</p><h3 className="text-2xl font-bold text-slate-900 mt-1">{computedStats.waitingCount}</h3></div><div className="p-2 bg-amber-100 rounded-lg"><RotateCcw className="w-5 h-5 text-amber-700" /></div></div>
        </Card>
        <Card className="p-4 bg-gradient-to-br from-emerald-50 to-white border-emerald-100">
           <div className="flex justify-between items-start"><div><p className="text-sm font-medium text-emerald-700">Selesai Hari Ini</p><h3 className="text-2xl font-bold text-slate-900 mt-1">{computedStats.todayDone}</h3></div><div className="p-2 bg-emerald-100 rounded-lg"><CheckCircle2 className="w-5 h-5 text-emerald-700" /></div></div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Focus Area */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-6 py-5 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
            <div><h2 className="text-lg font-bold text-slate-900 flex items-center"><AlertTriangle className="w-5 h-5 mr-2 text-indigo-500" /> Perlu Diperhatikan Sekarang</h2><p className="text-sm text-slate-500 mt-1">Rekomendasi prioritas berdasarkan urgensi dan tenggat waktu.</p></div>
            <Button variant="outline" size="sm" onClick={() => changeView('tasks')}>Semua</Button>
          </div>
          
          <div className="divide-y divide-slate-100">
            {computedStats.needsAttention.length > 0 ? (
              computedStats.needsAttention.map(task => (
                <div key={task.id} onClick={() => setSelectedTask(task)} className="p-5 hover:bg-slate-50 cursor-pointer transition-colors group flex flex-col sm:flex-row sm:items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1.5">
                      <Badge variant={getStatusColor(task.status)}>{task.status}</Badge>
                      <Badge variant={task.urgency === Urgency.VERY_URGENT ? 'danger' : 'default'} className={task.urgency === Urgency.VERY_URGENT ? 'animate-pulse' : ''}>{task.urgency}</Badge>
                    </div>
                    <h3 className="text-base font-semibold text-slate-900 group-hover:text-blue-700 truncate">{task.title}</h3>
                    <div className="flex flex-wrap items-center text-sm text-slate-500 mt-1 gap-y-1 gap-x-4">
                      <span className="flex items-center"><Users className="w-3.5 h-3.5 mr-1" /> {task.source}</span>
                      {task.due_at && (<span className={`flex items-center ${isOverdue(task.due_at) ? 'text-red-600 font-medium' : ''}`}><Clock className="w-3.5 h-3.5 mr-1" /> {formatDateID(task.due_at)}</span>)}
                    </div>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    {task.status !== Status.IN_PROGRESS && (<Button size="icon" variant="outline" onClick={(e:any) => { e.stopPropagation(); handleStatusChange(task.id, Status.IN_PROGRESS); }} title="Mulai Kerjakan"><Play className="w-4 h-4 text-blue-600" /></Button>)}
                    <Button size="icon" variant="outline" onClick={(e:any) => { e.stopPropagation(); handleStatusChange(task.id, Status.DONE); }} className="hover:bg-emerald-50 hover:border-emerald-200" title="Selesai"><CheckCircle2 className="w-4 h-4 text-emerald-600" /></Button>
                  </div>
                </div>
              ))
            ) : (
               <div className="p-12 text-center flex flex-col items-center"><div className="w-16 h-16 bg-emerald-50 rounded-full flex items-center justify-center mb-4"><CheckCircle2 className="w-8 h-8 text-emerald-500" /></div><h3 className="text-lg font-medium text-slate-900">Semua Terkendali!</h3><p className="text-slate-500 mt-1">Tidak ada pekerjaan mendesak saat ini.</p></div>
            )}
          </div>
        </div>

        {/* Side Panel */}
        <div className="space-y-6">
          <Card>
            <div className="px-4 py-3 border-b border-slate-100 bg-slate-50"><h3 className="font-bold text-slate-800 flex items-center"><CalendarDays className="w-4 h-4 mr-2 text-blue-500"/> Agenda & Deadline Hari Ini</h3></div>
            <div className="divide-y divide-slate-100">
              {computedStats.agendaToday.length > 0 ? computedStats.agendaToday.map(task => (
                <div key={task.id} onClick={()=>setSelectedTask(task)} className="p-4 hover:bg-slate-50 cursor-pointer">
                  <p className="text-sm font-semibold text-slate-900 truncate">{task.title}</p>
                  <p className="text-xs text-slate-500 mt-1 flex justify-between"><span>{task.source}</span> {task.event_at ? new Date(task.event_at).toLocaleTimeString('id-ID', {hour:'2-digit', minute:'2-digit'}) : 'Deadline'}</p>
                </div>
              )) : <div className="p-4 text-sm text-slate-500 text-center">Tidak ada agenda hari ini.</div>}
            </div>
          </Card>
          
          <Card>
            <div className="px-4 py-3 border-b border-slate-100 bg-slate-50"><h3 className="font-bold text-slate-800 flex items-center"><RotateCcw className="w-4 h-4 mr-2 text-amber-500"/> Menunggu Data</h3></div>
            <div className="divide-y divide-slate-100">
              {workItems.filter(t => t.status === Status.WAITING_DATA && t.is_active).length > 0 ? workItems.filter(t => t.status === Status.WAITING_DATA && t.is_active).map(task => (
                <div key={task.id} onClick={()=>setSelectedTask(task)} className="p-4 hover:bg-slate-50 cursor-pointer">
                  <p className="text-sm font-semibold text-slate-900 truncate">{task.title}</p>
                  <div className="text-xs text-amber-700 bg-amber-50 rounded p-2 mt-2 border border-amber-100">Menunggu: <strong>{task.data_expected || '-'}</strong><br/>Dari: <strong>{task.person_expected || '-'}</strong></div>
                </div>
              )) : <div className="p-4 text-sm text-slate-500 text-center">Tidak ada yang ditunggu.</div>}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );

  // --- MODALS ---
  
  const TaskDetailModal = ({ task, onClose }: { task: WorkItem, onClose: () => void }) => {
    if (!task) return null;
    return (
      <div className="fixed inset-0 z-[50] flex justify-end">
        {/* Backdrop doesn't scroll body, fixes background jump */}
        <div className="absolute inset-0 bg-slate-900/30 backdrop-blur-sm transition-opacity" onClick={onClose} />
        <div className="relative w-full max-w-2xl bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-300 border-l border-slate-200">
          <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
            <h2 className="text-lg font-bold text-slate-800">{task.is_active ? 'Detail Pekerjaan' : 'Detail Arsip Pekerjaan'}</h2>
            <div className="flex gap-2">
              {task.is_active && (
                <>
                  <button onClick={() => { setEditTaskModal({isOpen: true, task: task}); onClose(); }} className="p-2 hover:bg-blue-100 rounded-full text-blue-600 transition-colors" title="Edit Data"><Edit3 className="w-5 h-5" /></button>
                  <button onClick={() => { setDeleteConfirmModal({isOpen:true, entityType:'WorkItem', id: task.id, title: task.title}); onClose(); }} className="p-2 hover:bg-red-100 rounded-full text-red-600 transition-colors" title="Arsipkan/Nonaktifkan"><Archive className="w-5 h-5" /></button>
                </>
              )}
              <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full text-slate-500 transition-colors" title="Tutup"><X className="w-5 h-5" /></button>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-6 space-y-8">
            {!task.is_active && (
               <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl flex items-start gap-3">
                 <Archive className="w-5 h-5 mt-0.5 shrink-0"/>
                 <div><strong>Data ini telah diarsipkan/dinonaktifkan.</strong><br/>Alasan: {task.delete_reason || 'Tidak ada alasan'}<br/>Oleh: {task.deleted_by} pada {formatDateID(task.deleted_at, true)}</div>
               </div>
            )}
            <div>
              <div className="flex items-center gap-2 mb-3"><Badge variant={getStatusColor(task.status)}>{task.status}</Badge><Badge variant={task.urgency === Urgency.VERY_URGENT ? 'danger' : 'default'}>{task.urgency}</Badge><Badge variant="outline">{task.work_type}</Badge></div>
              <h1 className="text-2xl font-bold text-slate-900 mb-2 leading-tight">{task.title}</h1>
              <p className="text-slate-600 text-sm leading-relaxed whitespace-pre-wrap">{task.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100 text-sm">
              <div><span className="block text-slate-500 mb-1">Sumber / Peminta</span><span className="font-medium text-slate-900">{task.requester_name} ({task.source})</span></div>
              <div><span className="block text-slate-500 mb-1">Tenggat Waktu</span><span className={`font-medium ${isOverdue(task.due_at) && task.status !== Status.DONE ? 'text-red-600' : 'text-slate-900'}`}>{formatDateID(task.due_at)}</span></div>
              <div><span className="block text-slate-500 mb-1">Prioritas</span><span className="font-medium text-slate-900">{task.priority}</span></div>
              <div><span className="block text-slate-500 mb-1">Dibuat Pada</span><span className="font-medium text-slate-900">{formatDateID(task.created_at, true)}</span></div>
            </div>

            {task.is_active && (
              <div className="space-y-3">
                <h3 className="font-semibold text-slate-900 flex items-center">Aksi Status</h3>
                <div className="flex flex-wrap gap-2 bg-white p-3 border border-slate-200 rounded-xl">
                  {task.status !== Status.DONE && (
                    <>
                      <Button variant="primary" onClick={() => handleStatusChange(task.id, Status.DONE)}><CheckCircle2 className="w-4 h-4 mr-2"/> Selesai</Button>
                      <Button variant="outline" onClick={() => handleStatusChange(task.id, Status.IN_PROGRESS)}><Play className="w-4 h-4 mr-2 text-blue-600"/> Mulai/Lanjutkan</Button>
                      <Button variant="outline" onClick={() => { setPostponeModal({isOpen: true, task}); onClose(); }}><Pause className="w-4 h-4 mr-2 text-slate-600"/> Tunda</Button>
                      <Button variant="outline" onClick={() => { setWaitDataModal({isOpen: true, task}); onClose(); }}><RotateCcw className="w-4 h-4 mr-2 text-amber-600"/> Tunggu Data</Button>
                    </>
                  )}
                  {task.status === Status.DONE && (<Button variant="outline" onClick={() => handleStatusChange(task.id, Status.IN_PROGRESS)}><RotateCcw className="w-4 h-4 mr-2 text-amber-600"/> Buka Kembali Pekerjaan</Button>)}
                </div>
                
                {task.status === Status.POSTPONED && task.postpone_reason && (
                  <div className="p-3 bg-slate-100 border border-slate-200 rounded-lg mt-2 text-sm text-slate-700 flex items-start"><Pause className="w-4 h-4 mr-2 mt-0.5 text-slate-500 shrink-0"/> <div><strong>Ditunda hingga {formatDateID(task.postpone_until)}:</strong> {task.postpone_reason}</div></div>
                )}
                {task.status === Status.WAITING_DATA && (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg mt-2 text-sm text-amber-800 flex items-start"><Clock className="w-4 h-4 mr-2 mt-0.5 text-amber-600 shrink-0"/> <div><strong>Menunggu Data:</strong> {task.data_expected} <br/><strong>Dari:</strong> {task.person_expected}</div></div>
                )}
                {task.notes && (
                  <div className="p-3 bg-blue-50 border border-blue-100 rounded-lg mt-2 text-sm text-blue-800 flex items-start"><Sparkles className="w-4 h-4 mr-2 mt-0.5 text-blue-500 shrink-0"/> <div>{task.notes}</div></div>
                )}
              </div>
            )}

            {/* Smart Relations */}
            <div>
              <h3 className="font-semibold text-slate-900 flex items-center mb-3"><LinkIcon className="w-4 h-4 mr-2 text-slate-400"/> Hubungan Konteks</h3>
              {task.related_entities > 0 ? (
                <div className="p-3 border border-slate-200 rounded-lg flex items-center justify-between bg-slate-50">
                  <div className="flex items-center"><School className="w-4 h-4 mr-2 text-slate-400" /><span className="text-sm font-medium">Terkait Data Master (Siswa/Guru)</span></div>
                  <Badge variant="default">{task.related_entities} Entitas</Badge>
                </div>
              ) : <p className="text-sm text-slate-500 italic">Belum ada konteks terkait.</p>}
            </div>

            {/* History */}
            <div>
              <h3 className="font-semibold text-slate-900 flex items-center mb-4"><History className="w-4 h-4 mr-2 text-slate-400"/> Riwayat Aktivitas</h3>
              <div className="space-y-4 relative before:absolute before:inset-0 before:ml-2 md:before:mx-0 before:h-full before:w-0.5 before:bg-slate-200 ml-2">
                 {auditLogs.filter(l => l.entity_id === task.id).map((hist) => (
                    <div key={hist.id} className="relative flex items-center group pl-6">
                      <div className="absolute left-0 -translate-x-[9px] w-4 h-4 rounded-full border-2 border-white bg-blue-500"></div>
                      <div className="w-full p-3 rounded-lg border border-slate-100 bg-white shadow-sm">
                          <div className="flex justify-between mb-1"><span className="font-semibold text-slate-900 text-sm">{hist.action}</span><span className="text-xs text-slate-500">{formatDateID(hist.timestamp, true)}</span></div>
                          <div className="text-xs text-slate-600">Oleh {hist.actor} {hist.notes && `- ${hist.notes}`}</div>
                      </div>
                    </div>
                 ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const PostponeModal = () => {
    if(!postponeModal.isOpen || !postponeModal.task) return null;
    return (
      <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/50 p-4">
        <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-100 bg-slate-50 font-bold flex justify-between">Tunda Pekerjaan <button onClick={()=>setPostponeModal({isOpen:false, task:null})}><X className="w-5 h-5 text-slate-400 hover:text-slate-600"/></button></div>
          <form className="p-4 space-y-4" onSubmit={async (e: any) => {
            e.preventDefault();
            await api.postpone(postponeModal.task!.id, new Date(e.target.date.value).toISOString(), e.target.reason.value);
            showToast("Pekerjaan berhasil ditunda");
            await refreshData();
            setPostponeModal({isOpen:false, task:null});
          }}>
            <div><label className="block text-sm font-medium mb-1">Tunda Hingga Tanggal</label><input type="date" name="date" required className="w-full border-slate-300 rounded-lg text-sm" min={getNow().toISOString().split('T')[0]} /></div>
            <div><label className="block text-sm font-medium mb-1">Alasan Penundaan</label><textarea name="reason" required rows={3} className="w-full border-slate-300 rounded-lg text-sm" placeholder="Contoh: Menunggu server pusat up..."></textarea></div>
            <div className="pt-2 flex justify-end gap-2"><Button variant="outline" onClick={()=>setPostponeModal({isOpen:false, task:null})}>Batal</Button><Button type="submit">Simpan Penundaan</Button></div>
          </form>
        </div>
      </div>
    );
  };

  const WaitDataModal = () => {
    if(!waitDataModal.isOpen || !waitDataModal.task) return null;
    return (
      <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/50 p-4">
        <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-100 bg-slate-50 font-bold flex justify-between">Tunggu Data/Pihak Lain <button onClick={()=>setWaitDataModal({isOpen:false, task:null})}><X className="w-5 h-5 text-slate-400 hover:text-slate-600"/></button></div>
          <form className="p-4 space-y-4" onSubmit={async (e: any) => {
            e.preventDefault();
            await api.waitData(waitDataModal.task!.id, e.target.data.value, e.target.person.value);
            showToast("Status diubah menjadi Menunggu Data");
            await refreshData();
            setWaitDataModal({isOpen:false, task:null});
          }}>
            <div><label className="block text-sm font-medium mb-1">Data/Hal yang ditunggu</label><input type="text" name="data" required className="w-full border-slate-300 rounded-lg text-sm" defaultValue={waitDataModal.task!.data_expected || ''} /></div>
            <div><label className="block text-sm font-medium mb-1">Dari Pihak (Siapa)</label><input type="text" name="person" required className="w-full border-slate-300 rounded-lg text-sm" defaultValue={waitDataModal.task!.person_expected || ''} /></div>
            <div className="pt-2 flex justify-end gap-2"><Button variant="outline" onClick={()=>setWaitDataModal({isOpen:false, task:null})}>Batal</Button><Button type="submit">Ubah Status</Button></div>
          </form>
        </div>
      </div>
    );
  };

  const EditTaskModal = () => {
    if(!editTaskModal.isOpen || !editTaskModal.task) return null;
    const task = editTaskModal.task as WorkItem;
    const isNew = !task.id;
    return (
      <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/50 p-4">
        <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-100 bg-slate-50 font-bold flex justify-between">{isNew ? 'Buat Pekerjaan Baru' : 'Edit Pekerjaan'} <button onClick={()=>setEditTaskModal({isOpen:false, task:null})}><X className="w-5 h-5 text-slate-400 hover:text-slate-600"/></button></div>
          <form className="p-4 space-y-4 overflow-y-auto flex-1" onSubmit={async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target as HTMLFormElement);
            const data: Partial<WorkItem> = {
              title: formData.get('title') as string, description: formData.get('description') as string,
              work_type: formData.get('work_type') as WorkType, priority: formData.get('priority') as Priority,
              urgency: formData.get('urgency') as Urgency, source: formData.get('source') as string,
              requester_name: formData.get('requester_name') as string,
              due_at: formData.get('due_at') ? new Date(formData.get('due_at') as string).toISOString() : null,
              school_id: profile.activeSchoolId
            };
            if(isNew) { data.status = Status.INBOX; await api.createWorkItem(data); showToast("Pekerjaan berhasil dibuat!"); } 
            else { await api.updateWorkItem(task.id, data); showToast("Pekerjaan berhasil diperbarui!"); }
            await refreshData(); setEditTaskModal({isOpen:false, task:null});
          }}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2"><label className="block text-sm font-medium mb-1">Judul Pekerjaan</label><input type="text" name="title" required className="w-full border-slate-300 rounded-lg text-sm" defaultValue={task.title} /></div>
              <div className="md:col-span-2"><label className="block text-sm font-medium mb-1">Deskripsi/Instruksi</label><textarea name="description" rows={3} className="w-full border-slate-300 rounded-lg text-sm" defaultValue={task.description}></textarea></div>
              <div><label className="block text-sm font-medium mb-1">Jenis Pekerjaan</label><select name="work_type" className="w-full border-slate-300 rounded-lg text-sm" defaultValue={task.work_type || WorkType.TUGAS}>{Object.values(WorkType).map(v => <option key={v} value={v}>{v}</option>)}</select></div>
              <div><label className="block text-sm font-medium mb-1">Sumber/Via</label><input type="text" name="source" placeholder="Cth: WhatsApp, Surat Dinas" className="w-full border-slate-300 rounded-lg text-sm" defaultValue={task.source} /></div>
              <div><label className="block text-sm font-medium mb-1">Prioritas (Tingkat Kepentingan)</label><select name="priority" className="w-full border-slate-300 rounded-lg text-sm" defaultValue={task.priority || Priority.NORMAL}>{Object.values(Priority).map(v => <option key={v} value={v}>{v}</option>)}</select></div>
              <div><label className="block text-sm font-medium mb-1">Urgensi (Tingkat Keterdesakan)</label><select name="urgency" className="w-full border-slate-300 rounded-lg text-sm" defaultValue={task.urgency || Urgency.NORMAL}>{Object.values(Urgency).map(v => <option key={v} value={v}>{v}</option>)}</select></div>
              <div><label className="block text-sm font-medium mb-1">Peminta/Dari Siapa</label><input type="text" name="requester_name" className="w-full border-slate-300 rounded-lg text-sm" defaultValue={task.requester_name} /></div>
              <div><label className="block text-sm font-medium mb-1">Tenggat Waktu (Deadline)</label><input type="datetime-local" name="due_at" className="w-full border-slate-300 rounded-lg text-sm" defaultValue={task.due_at ? new Date(new Date(task.due_at).getTime() - (new Date().getTimezoneOffset() * 60000)).toISOString().slice(0, 16) : ''} /></div>
            </div>
            <div className="pt-4 flex justify-end gap-2 border-t border-slate-100 mt-4"><Button variant="outline" onClick={()=>setEditTaskModal({isOpen:false, task:null})}>Batal</Button><Button type="submit"><Save className="w-4 h-4 mr-2"/> Simpan Pekerjaan</Button></div>
          </form>
        </div>
      </div>
    );
  };

  const DeleteConfirmModal = () => {
    if(!deleteConfirmModal.isOpen) return null;
    return (
      <div className="fixed inset-0 z-[70] flex items-center justify-center bg-slate-900/50 p-4">
        <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden border-t-4 border-red-500">
          <div className="p-6">
            <h3 className="text-lg font-bold text-slate-900 flex items-center mb-2"><AlertTriangle className="w-5 h-5 text-red-500 mr-2"/> Konfirmasi Penonaktifan</h3>
            <p className="text-sm text-slate-600 mb-4">Anda akan menonaktifkan/mengarsipkan: <strong>{deleteConfirmModal.title}</strong>. Data ini tidak akan dihapus permanen dan tetap dapat dilihat di menu Arsip.</p>
            <form onSubmit={async(e:any)=>{
              e.preventDefault();
              await api.softDelete(deleteConfirmModal.entityType, deleteConfirmModal.id, e.target.reason.value);
              showToast("Data berhasil diarsipkan", "info");
              await refreshData();
              setDeleteConfirmModal({isOpen:false, entityType:null, id:'', title:''});
            }}>
              <label className="block text-sm font-medium mb-1">Alasan (Opsional)</label>
              <input type="text" name="reason" className="w-full border-slate-300 rounded-lg text-sm mb-4" placeholder="Alasan menghapus/arsip..." />
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={()=>setDeleteConfirmModal({isOpen:false, entityType:null, id:'', title:''})}>Batal</Button>
                <Button variant="danger" type="submit">Arsipkan Data</Button>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }

  const GenericFormModal = () => {
     if(!genericFormModal.isOpen) return null;
     const { type, data } = genericFormModal;
     const isNew = !data;
     
     return (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-lg overflow-hidden">
             <div className="px-4 py-3 border-b border-slate-100 bg-slate-50 font-bold flex justify-between">{isNew ? `Tambah Data ${type}` : `Edit Data ${type}`} <button onClick={()=>setGenericFormModal({isOpen:false, type:'Teacher'})}><X className="w-5 h-5 text-slate-400 hover:text-slate-600"/></button></div>
             <form className="p-4 space-y-4" onSubmit={async (e:any) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                const payload:any = Object.fromEntries(formData.entries());
                payload.school_id = profile.activeSchoolId;
                if (type === 'Document') {
                  const selectedFile = formData.get('file');
                  if (selectedFile instanceof File && selectedFile.size > 0 && syncApiUrl && authUser) {
                    const uploaded = await uploadDocumentFile(selectedFile);
                    payload.file_type = uploaded.content_type; payload.size = `${(uploaded.size/1024/1024).toFixed(2)} MB`; payload.url = uploaded.url;
                  }
                  delete payload.file;
                }
                if (isNew) {
                   await api.createMasterData(type, payload);
                   showToast(`Data ${type} berhasil ditambahkan`);
                } else {
                   await api.updateMasterData(type, data.id, payload);
                   showToast(`Data ${type} berhasil diperbarui`);
                }
                if (type === 'Reminder' && payload.remind_at) { try { await scheduleReminder(isNew ? `local-${Date.now()}` : data.id, String(payload.title), String(payload.remind_at)); } catch {} }
                await refreshData();
                setGenericFormModal({isOpen:false, type:'Teacher'});
             }}>
                {type === 'Teacher' && (
                  <>
                    <div><label className="block text-sm font-medium mb-1">Nama Lengkap</label><input type="text" name="name" required className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.name}/></div>
                    <div className="grid grid-cols-2 gap-4">
                       <div><label className="block text-sm font-medium mb-1">NIP</label><input type="text" name="nip" className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.nip}/></div>
                       <div><label className="block text-sm font-medium mb-1">NUPTK</label><input type="text" name="nuptk" className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.nuptk}/></div>
                    </div>
                    <div><label className="block text-sm font-medium mb-1">Peran / Jabatan</label><input type="text" name="role" required className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.role}/></div>
                  </>
                )}
                {type === 'Student' && (
                  <>
                    <div><label className="block text-sm font-medium mb-1">Nama Siswa</label><input type="text" name="name" required className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.name}/></div>
                    <div className="grid grid-cols-2 gap-4">
                       <div><label className="block text-sm font-medium mb-1">NISN</label><input type="text" name="nisn" className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.nisn}/></div>
                       <div><label className="block text-sm font-medium mb-1">NIK</label><input type="text" name="nik" className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.nik}/></div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                       <div><label className="block text-sm font-medium mb-1">Kelas</label><input type="text" name="grade" required className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.grade}/></div>
                       <div><label className="block text-sm font-medium mb-1">Nama Ortu/Wali</label><input type="text" name="parent_name" className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.parent_name}/></div>
                    </div>
                  </>
                )}
                {type === 'Reminder' && (
                  <>
                    <div><label className="block text-sm font-medium mb-1">Judul Pengingat</label><input type="text" name="title" required className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.title}/></div>
                    <div><label className="block text-sm font-medium mb-1">Waktu Pengingat</label><input type="datetime-local" name="remind_at" required className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.remind_at ? new Date(new Date(data.remind_at).getTime() - new Date().getTimezoneOffset()*60000).toISOString().slice(0,16) : ''}/></div>
                  </>
                )}
                {type === 'Document' && (
                  <>
                    <div><label className="block text-sm font-medium mb-1">Nama/Judul Dokumen</label><input type="text" name="title" required className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.title}/></div>
                    <div><label className="block text-sm font-medium mb-1">File Dokumen (opsional)</label><input type="file" name="file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.xlsx" className="w-full border border-slate-300 rounded-lg text-sm p-2" /></div>
                    <div className="grid grid-cols-2 gap-4">
                      <div><label className="block text-sm font-medium mb-1">Jenis File</label><input type="text" name="file_type" placeholder="PDF, DOCX, JPG..." className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.file_type}/></div>
                      <div><label className="block text-sm font-medium mb-1">Ukuran</label><input type="text" name="size" placeholder="1.2 MB" className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.size}/></div>
                    </div>
                    <div><label className="block text-sm font-medium mb-1">Catatan/Ringkasan</label><textarea name="summary" rows={3} className="w-full border-slate-300 rounded-lg text-sm" defaultValue={data?.summary}/></div>
                  </>
                )}
                <div className="pt-2 flex justify-end gap-2"><Button variant="outline" onClick={()=>setGenericFormModal({isOpen:false, type:'Teacher'})}>Batal</Button><Button type="submit">Simpan Data</Button></div>
             </form>
          </div>
        </div>
     );
  }

  const AIConfirmModal = () => {
    if(!aiConfirmModal.isOpen || !aiConfirmModal.data) return null;
    const data = aiConfirmModal.data;
    return (
       <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/50 p-4">
        <div className="bg-white rounded-xl shadow-xl w-full max-w-xl overflow-hidden border-t-4 border-indigo-500">
          <div className="px-4 py-3 border-b border-slate-100 bg-slate-50 font-bold flex items-center gap-2"><Sparkles className="w-5 h-5 text-indigo-500"/> Konfirmasi Analisis AI <div className="flex-1"></div><button onClick={()=>setAiConfirmModal({isOpen:false, data:null})}><X className="w-5 h-5 text-slate-400 hover:text-slate-600"/></button></div>
          <div className="p-6 space-y-4 text-sm text-slate-700">
            <p>AI telah membaca input Anda dan menyarankan detail pekerjaan berikut. Silakan konfirmasi atau sesuaikan melalui menu edit nanti.</p>
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-2">
              <div><strong>Judul Disarankan:</strong> {data.title}</div>
              <div><strong>Jenis:</strong> <Badge variant="outline">{data.work_type || 'Belum diketahui'}</Badge></div>
              <div><strong>Prioritas/Urgensi:</strong> {data.priority} / <span className={data.urgency===Urgency.VERY_URGENT ? 'text-red-600 font-bold' : ''}>{data.urgency}</span></div>
              {data.due_at && <div><strong>Terdeteksi Deadline:</strong> {formatDateID(data.due_at)}</div>}
              {data.notes && <div className="mt-2 text-indigo-700 bg-indigo-50 p-2 rounded italic">ℹ️ {data.notes}</div>}
            </div>
          </div>
          <div className="px-4 py-3 border-t border-slate-100 bg-white flex justify-end gap-2">
            <Button variant="outline" onClick={()=>setAiConfirmModal({isOpen:false, data:null})}>Batal</Button>
            <Button onClick={async () => {
               await api.createWorkItem({...data, status: Status.INBOX});
               showToast("Pekerjaan dari AI berhasil disimpan");
               await refreshData();
               setAiConfirmModal({isOpen:false, data:null});
            }}>Simpan ke Pekerjaan</Button>
          </div>
        </div>
       </div>
    );
  }

  // --- ADDITIONAL VIEWS ---
  const GenericMasterDataView = ({ title, columns, data, icon: Icon, entityType }: any) => (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[calc(100vh-120px)] animate-in fade-in">
       <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
          <h2 className="text-xl font-bold flex items-center"><Icon className="w-5 h-5 mr-2 text-blue-600"/> Data {title}</h2>
          <Button size="sm" onClick={()=>setGenericFormModal({isOpen:true, type: entityType})}><Plus className="w-4 h-4 mr-1" /> Tambah {title}</Button>
       </div>
       <div className="flex-1 overflow-y-auto p-4">
         <table className="min-w-full divide-y divide-slate-200">
           <thead className="bg-slate-50 text-xs font-medium text-slate-500 uppercase">
             <tr>{columns.map((col:string) => <th key={col} className="px-4 py-3 text-left">{col}</th>)}<th className="px-4 py-3">Aksi</th></tr>
           </thead>
           <tbody className="divide-y divide-slate-100">
             {data.length > 0 ? data.map((row:any) => (
               <tr key={row.id} className="hover:bg-slate-50">
                 {Object.keys(row).filter(k => !['id', 'school_id', 'created_at', 'updated_at', 'deleted_at', 'deleted_by', 'delete_reason', 'is_active'].includes(k)).map((k) => (
                   <td key={k} className="px-4 py-3 text-sm text-slate-700">{typeof row[k] === 'boolean' ? (row[k] ? 'Aktif' : 'Non-aktif') : row[k]}</td>
                 ))}
                 <td className="px-4 py-3 text-right">
                    <Button variant="ghost" size="icon" title="Edit" onClick={()=>setGenericFormModal({isOpen:true, type: entityType, data: row})}><Edit3 className="w-4 h-4 text-blue-500"/></Button>
                    <Button variant="ghost" size="icon" title="Arsipkan" onClick={()=>setDeleteConfirmModal({isOpen:true, entityType, id: row.id, title: row.name})}><Archive className="w-4 h-4 text-red-500"/></Button>
                 </td>
               </tr>
             )) : <tr><td colSpan={columns.length+1} className="p-8 text-center text-slate-500">Belum ada data {title}.</td></tr>}
           </tbody>
         </table>
       </div>
    </div>
  );

  const HistoryView = () => (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[calc(100vh-120px)] animate-in fade-in">
       <div className="p-4 border-b border-slate-100 bg-slate-50/50"><h2 className="text-xl font-bold flex items-center"><History className="w-5 h-5 mr-2 text-indigo-600"/> Riwayat Aktivitas Global</h2></div>
       <div className="flex-1 overflow-y-auto p-6 space-y-4 relative before:absolute before:inset-0 before:ml-8 before:h-full before:w-0.5 before:bg-slate-200">
         {auditLogs.length > 0 ? auditLogs.map((log) => (
            <div key={log.id} className="relative flex items-start group pl-12">
              <div className="absolute left-6 -translate-x-[9px] w-4 h-4 rounded-full border-2 border-white bg-slate-500 mt-1"></div>
              <div className="w-full p-4 rounded-xl border border-slate-100 bg-slate-50 hover:bg-white shadow-sm transition-colors">
                  <div className="flex justify-between items-start mb-2">
                     <div>
                       <span className="font-bold text-slate-900">{log.action}</span>
                       <Badge variant="outline" className="ml-2 text-[10px]">{log.entity_type}</Badge>
                     </div>
                     <span className="text-xs font-medium text-slate-500">{formatDateID(log.timestamp, true)}</span>
                  </div>
                  <div className="text-sm text-slate-600">Oleh: <strong>{log.actor}</strong> {log.notes && <span className="block mt-1 text-slate-500 italic">Catatan: {log.notes}</span>}</div>
              </div>
            </div>
         )) : <div className="text-center p-8 text-slate-500">Belum ada aktivitas.</div>}
       </div>
    </div>
  );

  const DocumentsView = () => (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col h-[calc(100vh-120px)] animate-in fade-in">
      <div className="p-4 border-b border-slate-100 bg-slate-50/50"><h2 className="text-xl font-bold flex items-center"><FileText className="w-5 h-5 mr-2 text-indigo-600"/> Manajemen Dokumen</h2></div>
      <div className="p-6 flex-1 overflow-y-auto">
         <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center bg-slate-50 hover:bg-slate-100 transition-colors cursor-pointer mb-6" onClick={()=>setGenericFormModal({isOpen:true, type:'Document'})}>
            <UploadCloud className="w-12 h-12 mx-auto text-slate-400 mb-3" />
            <h3 className="text-lg font-semibold text-slate-700">Klik atau Tarik Dokumen ke sini</h3>
            <p className="text-sm text-slate-500 mt-1">Mendukung PDF, DOCX, JPG/PNG (Maks 10MB)</p>
         </div>
         <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800 flex gap-3 mb-6">
           <CloudOff className="w-5 h-5 shrink-0"/>
           <div><strong>Google Drive / Supabase Storage Belum Terhubung</strong><br/>Silakan konfigurasikan OAuth atau API Keys di backend untuk mengaktifkan upload aktual. Saat ini berjalan dalam Mode Lokal (Adapter).</div>
         </div>
         
         <h3 className="font-bold text-slate-800 mb-3">Dokumen Tersimpan (Database Lokal)</h3>
         <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {documents.length > 0 ? documents.map(doc => (
               <div key={doc.id} className="p-4 border rounded-xl hover:border-blue-300">
                  <FileText className="w-8 h-8 text-blue-500 mb-2"/>
                  <h4 className="font-semibold text-sm truncate">{doc.title}</h4>
                  <p className="text-xs text-slate-500">{doc.file_type} • {doc.size}</p>
               </div>
            )) : <p className="text-sm text-slate-500">Belum ada dokumen.</p>}
         </div>
      </div>
    </div>
  );

  const AIAssistantView = () => (
     <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[calc(100vh-120px)] animate-in fade-in">
       <div className="p-4 border-b border-slate-100 bg-slate-50/50"><h2 className="text-xl font-bold flex items-center"><Sparkles className="w-5 h-5 mr-2 text-indigo-600"/> AI Assistant (Mode Ekstraksi)</h2></div>
       <div className="flex-1 p-6 flex flex-col items-center justify-center text-center">
         <Sparkles className="w-16 h-16 text-indigo-200 mb-4" />
         <h3 className="text-lg font-bold text-slate-800 mb-2">Simulasi AI NLP (Natural Language)</h3>
         <p className="text-sm text-slate-500 max-w-md mb-6">AI ini bertugas memahami konteks teks lepas (seperti pesan WhatsApp) dan merekomendasikan pembuatan pekerjaan beserta parameternya secara otomatis. Silakan coba mengetik pesan di kolom Beranda (atas).</p>
         <div className="bg-slate-50 border rounded-lg p-4 text-left text-sm max-w-lg w-full">
            <strong className="block mb-2">Contoh teks untuk dicoba di Dashboard:</strong>
            <ul className="list-disc pl-5 space-y-1 text-slate-600">
              <li>"Tolong print dokumen ini, Ibu butuh cepat"</li>
              <li>"Kirim data siswa kelas 1-6 untuk MBG besok"</li>
              <li>"Besok ada rapat sama dinas"</li>
            </ul>
         </div>
       </div>
     </div>
  );

  const saveSyncUrl = async () => {
    setSyncApiUrl(syncApiUrl);
    setSyncStatus(syncApiUrl ? 'Menguji koneksi server…' : 'Server online dinonaktifkan');
    if (!syncApiUrl) return;
    const ok = await pingSyncApi();
    setSyncStatus(ok ? 'Server terhubung' : 'Server belum dapat dihubungi');
    if (ok) await syncNow();
  };

  const SettingsView = () => (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm h-[calc(100vh-120px)] overflow-y-auto animate-in fade-in p-6">
      <h2 className="text-xl font-bold flex items-center mb-6"><Settings className="w-5 h-5 mr-2 text-slate-700"/> Pengaturan Sistem & Profil</h2>
      <div className="max-w-2xl space-y-8">
        <section>
          <h3 className="text-lg font-semibold border-b pb-2 mb-4">Profil Pengguna</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><label className="block text-sm font-medium mb-1">Nama Tampilan</label><input type="text" className="w-full border-slate-300 rounded-lg bg-slate-50" value={profile.name} onChange={e=>setProfile({...profile, name: e.target.value})} /></div>
            <div><label className="block text-sm font-medium mb-1">Email</label><input type="text" className="w-full border-slate-300 rounded-lg bg-slate-50" value={profile.email} onChange={e=>setProfile({...profile, email: e.target.value})} /></div>
          </div>
        </section>

        <section>
          <h3 className="text-lg font-semibold border-b pb-2 mb-4">Sekolah Aktif (Konteks Saat Ini)</h3>
          <div>
            <label className="block text-sm font-medium mb-1">Pilih Sekolah yang Dikelola</label>
            <select className="w-full border-slate-300 rounded-lg" value={profile.activeSchoolId} onChange={(e) => {setProfile({...profile, activeSchoolId: e.target.value});}}>
              {schools.map(s => <option key={s.id} value={s.id}>{s.name} (NPSN: {s.npsn})</option>)}
            </select>
            <p className="text-xs text-slate-500 mt-1">Mengubah sekolah akan langsung memfilter seluruh data pekerjaan, riwayat, dan master data ke konteks sekolah yang dipilih.</p>
          </div>
        </section>
        
        <section>
           <h3 className="text-lg font-semibold border-b pb-2 mb-4">Akun Online</h3>
           <div className="p-4 rounded-xl border border-indigo-100 bg-indigo-50/40 space-y-3">
             {authUser ? (
               <div className="flex flex-wrap items-center justify-between gap-3"><div><strong>{authUser.name}</strong><div className="text-xs text-slate-500">{authUser.email} • Sekolah: {authUser.school_id} • Peran: {authUser.role === 'kepala_sekolah' ? 'Kepala Sekolah' : authUser.role === 'admin' ? 'Admin' : 'Operator'}</div></div><Button variant="outline" onClick={handleLogout}>Keluar</Button></div>
             ) : (
               <form onSubmit={(e:any)=>{e.preventDefault();handleAuth();}} className="space-y-3">
                 {authMode==='register' && <input value={authName} onChange={e=>setAuthName(e.target.value)} placeholder="Nama operator" required className="w-full border-slate-300 rounded-lg" />}
                 <input type="email" value={authEmail} onChange={e=>setAuthEmail(e.target.value)} placeholder="Email" required className="w-full border-slate-300 rounded-lg" />
                 <input type="password" value={authPassword} onChange={e=>setAuthPassword(e.target.value)} placeholder="Kata sandi minimal 8 karakter" minLength={8} required className="w-full border-slate-300 rounded-lg" />
                 <div className="flex flex-wrap gap-2"><Button type="submit" disabled={authBusy || !syncApiUrl}>{authBusy ? 'Memproses…' : authMode==='login' ? 'Login' : 'Daftar Akun'}</Button><Button variant="ghost" onClick={()=>setAuthMode(authMode==='login'?'register':'login')}>{authMode==='login'?'Buat akun baru':'Kembali ke login'}</Button></div>
               </form>
             )}
             <p className="text-xs text-slate-500">Akun membatasi akses data online berdasarkan sekolah. Kata sandi hanya diproses oleh backend dan tidak disimpan di database lokal.</p>
           </div>
        </section>

        <section>
           <h3 className="text-lg font-semibold border-b pb-2 mb-4">Database Lokal & Backup</h3>
           <div className="p-4 rounded-xl border border-blue-100 bg-blue-50/50 space-y-3">
             <p className="text-sm text-slate-600">Data aplikasi tersimpan di perangkat melalui IndexedDB. Gunakan backup untuk memindahkan atau mengamankan data sebelum reset/pergantian tablet.</p>
             <div className="flex flex-wrap gap-2">
               <Button onClick={handleBackupExport}><Database className="w-4 h-4 mr-2"/> Backup Database</Button>
               <label className="inline-flex items-center justify-center font-medium rounded-lg border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 px-4 py-2 text-sm cursor-pointer">
                 <UploadCloud className="w-4 h-4 mr-2"/> Pulihkan Backup
                 <input type="file" accept="application/json,.json" className="hidden" onChange={e => handleBackupImport(e.target.files?.[0])}/>
               </label>
             </div>
             <p className="text-xs text-slate-500">Format: JSON • Backup berisi data sekolah, guru, siswa, pekerjaan, dokumen, pengingat, dan riwayat aktivitas.</p>
           </div>
        </section>

        <section>
           <h3 className="text-lg font-semibold border-b pb-2 mb-4">Sinkronisasi Online</h3>
           <div className="p-4 rounded-xl border border-emerald-100 bg-emerald-50/40 space-y-4">
             <div className="flex flex-wrap items-center justify-between gap-2">
               <div><strong>Mode {isOnline ? 'Online' : 'Offline'}</strong><div className="text-xs text-slate-500">{isOnline ? 'Koneksi internet terdeteksi.' : 'Perubahan tetap tersimpan lokal dan akan diantrikan.'}</div></div>
               <Badge variant={isOnline ? 'success' : 'outline'}>{isOnline ? 'Online' : 'Offline'}</Badge>
             </div>
             <div><label className="block text-sm font-medium mb-1">URL Backend API</label><input type="url" className="w-full border-slate-300 rounded-lg" placeholder="http://192.168.1.10:8000" value={syncApiUrl} onChange={e=>setSyncApiUrlState(e.target.value)} /></div>
             <div className="flex flex-wrap gap-2"><Button onClick={saveSyncUrl}><RefreshCw className="w-4 h-4 mr-2"/> Simpan & Sinkronkan</Button><Button variant="outline" onClick={syncNow} disabled={syncBusy || !syncApiUrl || !authUser}>{syncBusy ? 'Menyinkronkan…' : 'Sinkronkan Sekarang'}</Button></div>
             <div className="text-xs text-slate-500">{syncStatus} • {pendingSyncCount} perubahan menunggu sinkronisasi</div>
             <p className="text-xs text-slate-500">Gunakan HTTPS dan autentikasi pada server sebelum aplikasi dipakai melalui internet publik.</p>
           </div>
        </section>
      </div>
    </div>
  );

  // ==========================================
  // MAIN RENDER
  // ==========================================
  const activeSchool = schools.find(s => s.id === profile.activeSchoolId);

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-sans selection:bg-blue-100 text-slate-900 flex overflow-hidden">
      
      {/* Sidebar Desktop */}
      <aside className="hidden md:flex w-64 flex-col bg-white border-r border-slate-200 z-20 shrink-0">
        <div className="p-6 border-b border-slate-100">
          <div className="flex items-center gap-3">
             <div className="bg-blue-600 p-2 rounded-lg"><School className="w-6 h-6 text-white" /></div>
             <div><h1 className="font-bold text-sm leading-tight text-slate-900 line-clamp-2">{activeSchool?.name || 'Loading...'}</h1><span className="text-xs text-slate-500">NPSN: {activeSchool?.npsn}</span></div>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto px-3 py-4 scrollbar-thin"><SidebarNav /></div>
      </aside>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          <div className="fixed inset-0 bg-slate-900/50 transition-opacity" onClick={() => setIsMobileMenuOpen(false)} />
          <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white animate-in slide-in-from-left">
             <div className="absolute top-0 right-0 -mr-12 pt-2"><button className="flex items-center justify-center h-10 w-10 rounded-full text-white" onClick={() => setIsMobileMenuOpen(false)}><X className="h-6 w-6" /></button></div>
            <div className="p-6 border-b border-slate-100 bg-slate-50"><h1 className="font-bold text-lg">{activeSchool?.name}</h1><p className="text-sm text-slate-500">Operator: {profile.name}</p></div>
            <div className="flex-1 px-4 py-4 overflow-y-auto"><SidebarNav /></div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative min-w-0">
        <Topbar />
        
        {toastMessage && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 animate-in slide-in-from-top-5">
            <div className={`px-4 py-2 rounded-full shadow-lg text-sm font-bold text-white flex items-center ${toastMessage.type === 'error' ? 'bg-red-600' : toastMessage.type === 'info' ? 'bg-slate-700' : 'bg-emerald-600'}`}>
               <CheckCircle2 className="w-4 h-4 mr-2"/> {toastMessage.msg}
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 relative" id="main-scroll-area">
          {loading ? (
            <div className="h-full flex items-center justify-center"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div></div>
          ) : (
            <div className="max-w-7xl mx-auto h-full">
              
              {currentView === 'dashboard' && <DashboardView />}
              
              {currentView === 'tasks' && (
                <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[calc(100vh-120px)] animate-in fade-in">
                  <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-50/50">
                     <h2 className="text-xl font-bold flex items-center">{showArchived ? 'Arsip Pekerjaan' : 'Semua Pekerjaan Aktif'}</h2>
                     <div className="flex items-center gap-2 w-full sm:w-auto">
                       <label className="flex items-center text-sm mr-2 cursor-pointer text-slate-600"><input type="checkbox" className="mr-2 rounded" checked={showArchived} onChange={(e)=>setShowArchived(e.target.checked)}/> Tampilkan Arsip</label>
                       <div className="relative flex-1 sm:w-64">
                         <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                         <input type="text" placeholder="Cari..." className="w-full pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
                       </div>
                       <Button size="sm" variant="primary" onClick={() => setEditTaskModal({isOpen: true, task: {}})}><Plus className="w-4 h-4 mr-1" /> Buat</Button>
                     </div>
                  </div>
                  <div className="flex-1 overflow-y-auto">
                    <table className="min-w-full divide-y divide-slate-200">
                      <thead className="bg-slate-50 sticky top-0 z-10">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">Judul & Status</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase hidden md:table-cell">Prioritas/Urgensi</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase hidden sm:table-cell">Deadline/Agenda</th>
                          <th className="px-6 py-3"></th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-slate-100">
                        {workItems.length > 0 ? workItems.map((task) => (
                          <tr key={task.id} className={`hover:bg-slate-50 cursor-pointer ${!task.is_active ? 'opacity-60 bg-slate-50' : ''}`} onClick={() => setSelectedTask(task)}>
                            <td className="px-6 py-4">
                              <div className="text-sm font-semibold text-slate-900 mb-1 flex items-center">{!task.is_active && <Archive className="w-3 h-3 mr-1 text-red-500"/>} {task.title}</div>
                              <div className="flex items-center gap-2 flex-wrap">
                                <Badge variant={getStatusColor(task.status)}>{task.status}</Badge>
                                <span className="text-xs text-slate-500 flex items-center"><Users className="w-3 h-3 mr-1"/> {task.source}</span>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap hidden md:table-cell">
                              <div className="flex flex-col gap-1 items-start text-xs font-medium">
                                <span className="text-slate-700">P: {task.priority}</span><span className={task.urgency === Urgency.VERY_URGENT && task.is_active ? 'text-red-600' : 'text-slate-700'}>U: {task.urgency}</span>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 hidden sm:table-cell">
                               {task.due_at ? <span className={isOverdue(task.due_at) && task.status !== Status.DONE && task.is_active ? 'text-red-600 font-medium' : ''}><Clock className="w-3 h-3 inline mr-1"/>{formatDateID(task.due_at)}</span> : '-'}
                               {task.event_at && <div className="mt-1"><CalendarDays className="w-3 h-3 inline mr-1 text-blue-500"/>{formatDateID(task.event_at)}</div>}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              <Button variant="ghost" size="sm" onClick={(e:any) => { e.stopPropagation(); setSelectedTask(task); }}>Detail <ChevronRight className="w-4 h-4 ml-1 inline"/></Button>
                            </td>
                          </tr>
                        )) : <tr><td colSpan={4} className="text-center p-8 text-slate-500">Tidak ada data.</td></tr>}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Views Routing */}
              {currentView === 'teachers' && <GenericMasterDataView title="Guru" icon={Users} entityType="Teacher" data={teachers} columns={['Nama Lengkap', 'NIP', 'NUPTK', 'Jabatan/Peran']} />}
              {currentView === 'students' && <GenericMasterDataView title="Siswa" icon={Users} entityType="Student" data={students} columns={['Nama Siswa', 'NISN', 'NIK', 'Kelas', 'Nama Ortu/Wali']} />}
              {currentView === 'schools' && <GenericMasterDataView title="Sekolah Tersinkronisasi" icon={School} entityType="School" data={schools} columns={['Nama Sekolah', 'NPSN', 'Alamat']} />}
              {currentView === 'docs' && <DocumentsView />}
              {currentView === 'history' && <HistoryView />}
              {currentView === 'ai' && <AIAssistantView />}
              {currentView === 'settings' && <SettingsView />}
              
              {/* Coming Soon Overlays for smaller remaining modules */}
              {['agenda', 'reminders'].includes(currentView) && (
                 <div className="h-full flex flex-col items-center justify-center text-center animate-in fade-in p-6">
                    <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-6"><Settings className="w-10 h-10 text-slate-400" /></div>
                    <h2 className="text-2xl font-bold text-slate-900 mb-2">Tampilan {currentView.toUpperCase()}</h2>
                    <p className="text-slate-500 max-w-md">Data sudah dikelola di layar Pekerjaan dan Dashboard. UI khusus kalender untuk modul ini dapat diimplementasi menggunakan pustaka kalender eksternal (menunggu instalasi).</p>
                 </div>
              )}

            </div>
          )}
        </div>
      </main>

      {/* Modals Container (Using fixed positioning prevents scroll jump) */}
      <TaskDetailModal task={selectedTask as WorkItem} onClose={() => setSelectedTask(null)} />
      <PostponeModal />
      <WaitDataModal />
      <EditTaskModal />
      <AIConfirmModal />
      <DeleteConfirmModal />
      <GenericFormModal />
      
      {/* DEMO Label Fixed */}
      <div className="fixed bottom-4 right-4 bg-amber-400 text-amber-900 text-xs font-bold px-3 py-1.5 rounded-full shadow-lg z-50 pointer-events-none uppercase tracking-wider flex items-center">
        <AlertTriangle className="w-3 h-3 mr-1" /> {isOnline ? 'Online + Offline Ready' : 'Offline Ready'}
      </div>
    </div>
  );
}